<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// shopping cart brief info

	//calculate shopping cart value
	$k=0;
	$cnt = 0;
	if (isset($_SESSION["gids"])) //...session vars
	{
		for ($i=0; $i<count($_SESSION["gids"]); $i++)
		  if ($_SESSION["gids"][$i])
		  {
			$qprice = db_query("SELECT Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8 FROM ".CHARACTER_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
			$rprice = db_fetch_row($qprice);

			$cr1pr = $_SESSION["gids"][$i][1]; //��� �������
			$cr2pr = $_SESSION["gids"][$i][2]+6; //��� �������
			$cr3pr = $_SESSION["gids"][$i][3]+8; //��� ���������
			$cr4pr = $_SESSION["gids"][$i][4]+12; //��� �������

			$cnt += $_SESSION["counts"][$i][0]+$_SESSION["counts"][$i][2]+$_SESSION["counts"][$i][3]+$_SESSION["counts"][$i][4];
			$k += $_SESSION["counts"][$i][0]*$rprice[$cr1pr]+$_SESSION["counts"][$i][2]*$rprice[$cr2pr]+$_SESSION["counts"][$i][3]*$rprice[$cr3pr]+$_SESSION["counts"][$i][4]*$rprice[$cr4pr];
		  }
	}

	//minimal

	if ((($k < CONF_MINIMAL_SUMM) || ($kc < CONF_MINIMAL_COUNT)) && ($cnt>0) ) 
		{
		//$k += CONF_MINIMAL_COST; 
		//$cnt++;
		}
	else {unset($_SESSION["minimal"]);}



	$smarty->assign("shopping_cart_value", $k);
	$smarty->assign("shopping_cart_value_shown", show_price($k));
	$smarty->assign("shopping_cart_items", $cnt);

?>