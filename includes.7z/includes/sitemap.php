<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 Supme. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// auxiliary information page presentation


if (isset($_GET["sitemap"]))    
    {
        $smarty->assign("main_content_template", "sitemap.tpl.html");
    }
?>