<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 Supme. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// auxiliary information page presentation


if (isset($_GET["pages"]))    
    if ($_GET["pages"])

    {
	//calculate a path
	$path = Array();
	$row[0] = "index.php?pages";
	$row[1] = ADMIN_PAGES;
	$path[] = $row;

        $p = array();
        $q = db_query("SELECT title, text, date, brief, Pict, enable, meta_title, meta_keywords, meta_desc FROM ".PAGES_TABLE." WHERE id='".mysql_real_escape_string($_GET["pages"])."'") or die (db_error());
        $p = mysql_fetch_row($q);

	$row[0] = "index.php?pages=".$_GET["pages"];
	$row[1] = $p[0];
	$path[] = $row;

	$smarty->assign("product_category_path",$path);

	$smarty->assign("meta_title", $p[6]);
	$smarty->assign("meta_keywords", $p[7]);
	$smarty->assign("meta_desc", $p[8]);
        $smarty->assign("pagetext", $p);
        $smarty->assign("main_content_template", "pages.tpl.html");
    }
    else
    {
	//calculate a path
	$path = Array();
	$row[0] = "index.php?pages";
	$row[1] = ADMIN_PAGES;
	$path[] = $row;

	$smarty->assign("product_category_path",$path);

        $q = db_query("SELECT id, title, date, brief, Pict, enable FROM ".PAGES_TABLE." ") or die (db_error());
        $i=0;
        $news=array();
        while ($p=mysql_fetch_row($q))
            { 
                $pages[$i] = $p;
                $i++;
             }
        $smarty->assign("pageslist", $pages);
        $smarty->assign("main_content_template", "pages.tpl.html");
    }
?>