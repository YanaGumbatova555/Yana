<?php	
	$result = array();
	$q2 = db_query("SELECT productID, name, picture, Price, description, hurl, customers_rating FROM  ".PRODUCTS_TABLE." ORDER BY RAND()  LIMIT 40");
	while ($row2 = db_fetch_row($q2))
	{
		if (trim($row2[2])!="" && file_exists("./products_pictures/$row2[2]"))
		{
			$row2[3] = show_price($row2[3]);
			$result[] = $row2;
		}
	}
	$smarty->assign("lastnew_offers",$result);	
?>
