<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// shopping cart

	//calculate shopping cart value

	//header("Location: ".$_SERVER['HTTP_REFERER']);

	if (isset($_GET["shopping_cart"]) || isset($_POST["shopping_cart"]))
	{	
		if (isset($_GET["add2cart"]) && $_GET["add2cart"]>0) //add product to cart with productID=$add
		{	
			$q = db_query("select in_stock from ".PRODUCTS_TABLE." where productID='".$_GET["add2cart"]."'") or die (db_error());
			$is = db_fetch_row($q); $is = $is[0];

			if (!isset($_SESSION["gids"]))
			{
				$_SESSION["gids"] = array();
				$_SESSION["counts"] = array();
				$characterArray = array();
				$characterCounts = array();

			}
			//check for current item in the current shopping cart content
			$found=0;
			
			for ($i=0; $i<count($_SESSION["gids"]);$i++)
			    if ($_SESSION["gids"][$i][0] == $_GET["add2cart"] && $_SESSION["gids"][$i][1]==$_GET["p"])
				{$_SESSION["counts"][$i][0]++;
				 $_SESSION["counts"][$i][1]++;
				if ($_GET["kr"]>0) {$_SESSION["counts"][$i][2]++; $_SESSION["gids"][$i][2]==$_GET["kr"];}
				if ($_GET["n"]>0)
					{
					if ($_GET["n"]==1 || $_GET["n"]==3) 
						{$_SESSION["counts"][$i][3]+="0.5";} 
					else 	{$_SESSION["counts"][$i][3]++;}
					if ($_GET["n"]>2) 
						{$_SESSION["gids"][$i][3] = 4;}
					else 	{$_SESSION["gids"][$i][3] = 2;}
					}
				if ($_GET["d"]>0) {$_SESSION["counts"][$i][4]++; $_SESSION["gids"][$i][4]=$_GET["d"];}
				$found=1;
				}

			if ($found==0) //no item - add it to $gids array
			{
				$characterArray[0] = $_GET["add2cart"];
				$characterArray[1] = $_GET["p"];
				$characterArray[2] = $_GET["kr"];
				$characterArray[3] = $_GET["n"];
				$characterArray[4] = $_GET["d"];

				
				$characterCounts[0] = 1;
				$characterCounts[1] = 1;
				if ($_GET["kr"]>0) {$characterCounts[2] = 1;} else {$characterCounts[2] = 0;}
				if ($_GET["n"]>0) {$characterCounts[3] = 1;} else {$characterCounts[3] = 0;}
				if ($_GET["d"]>0) {$characterCounts[4] = 1;} else {$characterCounts[4] = 0;}
			
				$_SESSION["gids"][] = $characterArray;
				$_SESSION["counts"][] = $characterCounts;
			}

		  header("Location: index.php?shopping_cart=yes");
		}

		//remove from cart product

		if (isset($_GET["remove"]) && $_GET["remove"] > 0) //remove from cart product with productID == $remove
			for ($i=0; $i<count($_SESSION["gids"]);$i++)
			    if ($_SESSION["gids"][$i][0] == $_GET["remove"] && $_SESSION["gids"][$i][1]==$_GET["p"])
				{
				 if (isset($_GET['all'])) {$_SESSION["gids"][$i]=0; $_SESSION["counts"][$i]=0;}
				 if (isset($_GET['kr'])) {$_SESSION["gids"][$i][2]=0; $_SESSION["counts"][$i][2]=0;}
				 if (isset($_GET['n'])) {$_SESSION["gids"][$i][3]=0; $_SESSION["counts"][$i][3]=0;}
				 if (isset($_GET['d'])) {$_SESSION["gids"][$i][4]=0; $_SESSION["counts"][$i][4]=0;}
				}

		//update shopping cart content

		if (isset($_POST["update"])) //update shopping cart content
		{
		  foreach ($_POST as $key => $val)
		    if (strstr($key, "count_"))
		      { $a=explode('_',$key);
			$character1=str_replace("p","",$a[1]);
			$characterID=$a[2];
			$character2=$a[3];

			if ($val > 0)
			  for ($i=0; $i<count($_SESSION["gids"]); $i++)
			    if ($_SESSION["gids"][$i][0] == $characterID && $_SESSION["gids"][$i][1]==$character1)
			      if ($character2=="kr") {$_SESSION["counts"][$i][2] = $val;}
			      else if ($character2=="n") {$_SESSION["counts"][$i][3] = $val;}
				   else if ($character2=="d") {$_SESSION["counts"][$i][4] = $val;}
					else {$_SESSION["counts"][$i][0] = $val;}
		       }

			//fast_order

			if ($_POST["get_fast_order"]) 
				{$pf = (int)CONF_FAST_ORDER_COST;
				 $_SESSION["get_fast_order"] = $pf;
				}
			else {unset($_SESSION["get_fast_order"]);}

		  header("Location: index.php?shopping_cart=yes");
		}

		if (isset($_GET["clear_cart"])) //completely clear shopping cart
		{
			//clear cart
			unset($_SESSION["gids"]);
			unset($_SESSION["counts"]);
			unset($_SESSION["present"]);
			unset($_SESSION["minimal"]);
			unset($_SESSION["discount"]);

			header("Location: index.php?shopping_cart=yes");
		}

		//shopping cart items count
		$c = 0;
		if (isset($_SESSION["gids"]))
			for ($j=0; $j<count($_SESSION["gids"]); $j++)
				for ($k=0; $k<5; $k++)
					if ($_SESSION["gids"][$j]) $c += $_SESSION["counts"][$j][$k];



		//not empty?
		if (isset($_SESSION["gids"]) && $c)
		{
			$k = 0; //total cart value
			$products = array();
			for ($i=0; $i<count($_SESSION["gids"]); $i++)
			  if ($_SESSION["gids"][$i])
			  {
				$q = db_query("SELECT name, null, product_code, categoryID FROM ".PRODUCTS_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
				if ($r = db_fetch_row($q))
				{	$qprice = db_query("SELECT Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable FROM ".CHARACTER_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
					$rprice = db_fetch_row($qprice);
					
					$cr1pr = $_SESSION["gids"][$i][1]; //��� �������
					$cr2pr = $_SESSION["gids"][$i][2]+6; //��� �������
					$cr3pr = $_SESSION["gids"][$i][3]+8; //��� ���������
					$cr4pr = $_SESSION["gids"][$i][4]+12; //��� �������

					$enable_characters = $rprice[15];

					$tmp = array("id"=>$_SESSION["gids"][$i][0], "categoryID"=>$r[3], "name"=>$r[0], "quantity"=>$_SESSION["counts"][$i][0], "cost"=>show_price($_SESSION["counts"][$i][0]*$rprice[$cr1pr]), "product_code"=>$r[2], "character1"=>$_SESSION["gids"][$i][1], "character2"=>$_SESSION["gids"][$i][2], "character2price"=>show_price($_SESSION["counts"][$i][2]*$rprice[$cr2pr]), "character3"=>$_SESSION["gids"][$i][3], "character3price"=>show_price($_SESSION["counts"][$i][3]*$rprice[$cr3pr]), "character4"=>$_SESSION["gids"][$i][4], "character4price"=>show_price($_SESSION["counts"][$i][4]*$rprice[$cr4pr]), "character2count"=>$_SESSION["counts"][$i][2], "character3count"=>$_SESSION["counts"][$i][3], "character4count"=>$_SESSION["counts"][$i][4], "enable_characters"=>$enable_characters);

					$products[] = $tmp;

					$k += $_SESSION["counts"][$i][0]*$rprice[$cr1pr]+$_SESSION["counts"][$i][2]*$rprice[$cr2pr]+$_SESSION["counts"][$i][3]*$rprice[$cr3pr]+$_SESSION["counts"][$i][4]*$rprice[$cr4pr];
					$kc += $_SESSION["counts"][$i][0]+$_SESSION["counts"][$i][2]+$_SESSION["counts"][$i][3]+$_SESSION["counts"][$i][4];
				}
			
			  }
			//present

			$q = db_query("SELECT * FROM ".PRESENT_TABLE." WHERE 1") or die (db_error());

			$result = array();
			  while ($row = db_fetch_row($q))
			    {
				$result[] = $row;
			    }

			for ($i=0; $i<count($result); $i++)
			  {
			   if ($k>$result[$i][2]) {$present=$result[$i][1];}
			  }

			if ($present)
			  {
			   $q = db_query("SELECT categoryID, name, productID FROM ".PRODUCTS_TABLE." where productID='$present' and enabled=1") or die (db_error());
			   $pr = db_fetch_row($q);
			   $_SESSION["present"] = $pr;
			   $smarty->assign("present", $pr);
			  }
			else {unset($_SESSION["present"]);}

			//minimal

			if (($k < CONF_MINIMAL_SUMM) || ($kc < CONF_MINIMAL_COUNT)) 
				{
				 $_SESSION["minimal"][0] = CONF_MINIMAL_PRODUCT;
				 $_SESSION["minimal"][1] = CONF_MINIMAL_COST;
				 $smarty->assign("minimal", $_SESSION["minimal"]);
				 $k += CONF_MINIMAL_COST;
				}
			else { unset($_SESSION["minimal"]); }

			//discount

			if ($k > CONF_DISCOUNT_VALUE)
				{
				  $discount = round($k/100*CONF_DISCOUNT_PR);
				  $_SESSION["discount"] = $discount;
				  $smarty->assign("discount", $discount);
				  $k -= $discount;
				}

			//fast order

			if ($_SESSION["get_fast_order"])
				{ $pf = $_SESSION["get_fast_order"];
				  $smarty->assign("get_fast_order", $pf);
			 	  $k += $pf;
				}

			//total...

			$smarty->assign("cart_content", $products);
			$smarty->assign("cart_total", show_price($k));

		}
		else
		{
			$smarty->assign("cart_total", "");
		}

		$smarty->assign("go_back", $_SERVER['HTTP_REFERER']);
		$smarty->assign("main_content_template", "shopping_cart.tpl.html");


	}
?>