<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 Supme. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// contact send mail
if (isset($_GET["contact"]))
{
	$smarty->assign("main_content_template", "contact.tpl.html");
}

if (isset($_GET["send_result"])) //show 'send result' page
  {		
	$smarty->assign("send_result", $_GET["send_result"]);
	$smarty->assign("main_content_template", "contact.tpl.html");	
  }

if (isset($_POST["send_mail"]))
  {
	$Name = $_POST['send_name'];
	$From = $_POST['send_email'];
	$Body = $_POST['send_text'];

		if (($Name=="") or ($From=="") or ($Body=="") or (!preg_match("/[-0-9a-z_]+@[-0-9a-z_]+\.[a-z]{2,6}/i",$From)) or ($_POST["captcha"]<>$_SESSION["captcha"])) 
			{$send_result=0;}
		   else	{
				$To = CONF_GENERAL_EMAIL;
				$Subj = STRING_MAIL_FROM_SITE;

				$headers  = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type: text/html; charset=windows-1251" . "\r\n";
				$headers .= "From: ".$From . "\r\n";

				$mail = "��: ".$Name."<br>\r\n";
				$mail .="�����: ".$From."<br>\r\n";
				$mail .="����� ���������: <br>\r\n".$Body."\r\n";
						
				if (mail($To,$Subj,$mail,$headers)) 
					{$send_result=2;}
				   else {$send_result=1;}
			}

	//show sent result
	unset($_SESSION["captcha"]);

	$f = file("./cfg/contact");
	        $out = implode("", $f);
	$smarty->assign("contact_info", $out);

	header("Location: index.php?send_result=".$send_result);
  }

?>