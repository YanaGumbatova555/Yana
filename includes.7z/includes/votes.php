<?php

if (CONF_VOTES_ON==1)
{
  if ((isset($_POST["vote_send"])) && ($_POST["vote_send"]))
	{
	db_query("UPDATE ".VOTES_CONTENT_TABLE." SET `result`=`result`+'1' WHERE votesID='".$_POST["vote_send"]."' AND ID='".$_POST["vote"]."'") or die (db_error());
	$_SESSION["votes_complete"] = 1;
	header("Location: ".$_SERVER['HTTP_REFERER']);
	}

    $q = db_query("SELECT ".VOTES_TABLE.".votesID, title, enable, ID, question, result FROM ".VOTES_TABLE." LEFT JOIN ".VOTES_CONTENT_TABLE." USING(votesID) WHERE enable='1' ORDER BY ID ASC") or die (db_error());

    $vt_cnt = 0;
    while ($p=mysql_fetch_row($q))
	if ($p[4] !== "")
	   {
	    $vote_is[] = $p;
	    $vt_cnt += $p[5];
	   }

    if (($_SESSION["votes_complete"]) && ($_SESSION["votes_complete"]==1)) //showing results
	 {
		for ($i=0; $i<count($vote_is);$i++)
		    $vote_is[$i][6]=round($vote_is[$i][5]*100/$vt_cnt);

		$smarty->assign("vote_res", $vote_is);  
	 }
    else {$smarty->assign("vote_is", $vote_is);}
}

?>