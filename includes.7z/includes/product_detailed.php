<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// product detailed information view


	if (isset($_POST["vote"]) && isset($productID)) //vote for a product
	{
		if (!isset($_SESSION["vote_completed"][ $productID ]) && isset($_POST["mark"]) && $_POST["mark"])
		{
			$q = db_query("UPDATE ".PRODUCTS_TABLE." SET customers_rating=(customers_rating*customer_votes+'".(int)$_POST["mark"]."')/(customer_votes+1), customer_votes=customer_votes+1 WHERE productID='".$productID."'") or die (db_error());
		}
		$_SESSION["vote_completed"][ $productID ] = 1;
	}

	if (isset($_POST["review"]) && isset($productID) && ($_POST["captcha"] == $_SESSION["captcha"])) //review for a product
	{
		if(isset($_POST["name"]) & isset($_POST["email"]) & isset($_POST["review"]))
		{
			$q = db_query("INSERT INTO ".REVIEW_TABLE."(productID, username, email, review) VALUES('".(int)$productID."','".$_POST["name"]."','".$_POST["email"]."','".str_replace("\n","<br />\n",$_POST["review"])."')") or die (db_error());
		}
		$smarty->assign("review_saved", "yes");

		//notification for administrator
		$adm .= "\n".CUSTOMER_FIRST_NAME.": ".$_POST["name"]."\n".CUSTOMER_EMAIL.": ".$_POST["email"]."\n".PRODUCT_REVIEW_MESSAGE.":\n".$_POST["review"];
		mail(CONF_ORDERS_EMAIL, PRODUCT_REVIEW_NOTIFICATION_SUBJECT, $adm, "From: \"".CONF_SHOP_NAME."\"<".CONF_GENERAL_EMAIL.">\n".stripslashes(EMAIL_MESSAGE_PARAMETERS)."\nReturn-path: <".CONF_GENERAL_EMAIL.">");

		unset($_SESSION["captcha"]);

		header("Location: ".$_SERVER['HTTP_REFERER']);
	}

	if (isset($productID) && $productID>0)
	{

			$smarty->assign("main_content_template", "product_detailed.tpl.html");

			$q = db_query("SELECT categoryID, ".PRODUCTS_TABLE.".name, ".PRODUCTS_TABLE.".description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, big_picture, list_price, productID, product_code, brief_description, hurl, accompanyID, ".PRODUCTS_TABLE.".meta_title, ".PRODUCTS_TABLE.".meta_keywords, ".PRODUCTS_TABLE.".meta_desc, ".PRODUCTS_TABLE.".brandID, ".BRAND_TABLE.".name FROM ".PRODUCTS_TABLE." LEFT JOIN ".BRAND_TABLE." USING (brandID) WHERE productID='$productID' and enabled=1") or die (db_error());
			$a = db_fetch_row($q);

			if ($a) //product found
			{
				$smarty->assign("meta_title", $a[16]);
				$smarty->assign("meta_keywords", $a[17]);
				$smarty->assign("meta_desc", $a[18]);

				//update several product fields
				if (!file_exists("./products_pictures/".$a[5])) $a[5] = 0;
				if (!file_exists("./products_pictures/".$a[7])) $a[7] = 0;
				if (!file_exists("./products_pictures/".$a[9])) $a[9] = 0;

				$a[21] = show_price($a[4]);
				$a[22] = show_price($a[10]);
				$a[23] = show_price($a[10]-$a[4]); //you save (value)
				if ($a[10]) $a[24] = ceil(((($a[10]-$a[4])/$a[10])*100)); //you save (%)


				if ($a[6] > 0) {$a[25]=1;}
				else 
				    if (CONF_SHOW_ADD2CART_INSTOCK > 0)
					{$a[25]=1;}
				    else {$a[25]=0;}

				$smarty->assign("product_info", $a);


			//calculate a path to the category
				$path = array();
				$curr = $categoryID;
				do
				{
					$q = db_query("SELECT parent, name, hurl FROM ".CATEGORIES_TABLE." WHERE categoryID='$curr'") or die (db_error());
					$row = db_fetch_row($q);
					if ($row[2] != "") {$tmp = "catalog/".$row[2];} else {$tmp = "index.php?categoryID=".$curr;}

					$curr = $row[0]; //get parent ID
					$row[0] = $tmp;
					$path[] = $row;
				} while ($curr);
				//now reverse $path
				$path = array_reverse($path);

				if ($a[14] !="") {$row[0] = "catalog/".$a[14];} else {$row[0] = "index.php?productID=".$a[11];}
				$row[1] = $a[1];
				$path[] = $row;

				$smarty->assign("product_category_path",$path);

			//searching reviews

				$q = db_query("SELECT * FROM ".REVIEW_TABLE." WHERE productID=".$productID." ORDER BY date_time DESC") or die (db_error());
				$i=0;
				$reviews=array();
				while ($res=mysql_fetch_row($q))
				    { 
					$reviews[$i] = $res;
					$i++;
				    }
				$smarty->assign("reviews", $reviews);
				
				$qc = db_query("select Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable from ".CHARACTER_TABLE." where productID='$productID'") or die (db_error());
				$c = db_fetch_row($qc);
				$smarty->assign("characters", $c);

			//searching accompanyID
				if ($a[15]) 
				   {$ac=str_replace(" ","",$a[15]);
				    $ac=explode(",",$ac);
				    $accomp=array();
				    $i=0;

				    while ($i<count($ac)-1)
					{ $s .= "productID=$ac[$i] OR ";
					  $i++;
					}
				    $s .= "productID=$ac[$i]";

				    $qac = db_query("SELECT productID, categoryID, name, thumbnail, brief_description, hurl from ".PRODUCTS_TABLE." WHERE enabled=1 AND (".$s.")") or die (db_error());

				    while ($acc = db_fetch_row($qac)) $accomp[]=$acc;

				    $smarty->assign("accompany",$accomp);
				   }

			//searching all products in category

				$q = db_query("select productID, categoryID, name, thumbnail, price from ".PRODUCTS_TABLE." where categoryID='$a[0]' and enabled=1 ORDER BY productID ASC") or die (db_error());
				$out = array();
				$i=0;
				while ($row = db_fetch_row($q))
				 {
					$out[$i][0] = $row[0]; //productID
					$out[$i][1] = $row[2]; //name
					$out[$i][2] = $row[3]; //picture
					$out[$i][3] = $row[4]; //price
					$i++;
				 }
				$smarty->assign("product_all", $out);
				$smarty->assign("product_all_count", $i);

                	//more product photos
                   		$q = db_query("SELECT picture, description FROM ".THUMB_TABLE." WHERE productID='".$a[11]."'") or die (db_error());
                    		$i=0;
                      		while ($qe=mysql_fetch_array($q))
					{ 
                        		$pic[$i] = $qe["picture"];
                        		$desc[$i] = $qe["description"];
                        		$i++;
                                    	}
                    		if (isset($pic))
					{
                        		$smarty->assign("product_thumb", $pic);
                        		$smarty->assign("product_desc", $desc);
                    			}
			}
			else
			{
				//product not found
				header("Location: index.php");
			}
	}

?>