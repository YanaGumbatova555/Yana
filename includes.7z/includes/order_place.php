<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/


	//place order: save to the database, send notifications, gateway processing

	if (isset($_GET["order_placement_result"])) //show 'order successful' page
	{
		$q = db_query("SELECT orderID, cust_firstname, cust_lastname, cust_email, cust_city, cust_address, cust_phone, comment FROM ".ORDERS_TABLE." WHERE orderID=".$_SESSION["order_id"]) or die (db_error());
		$result = db_fetch_row($q);
		
		$q = db_query("SELECT name, Price, Quantity FROM ".ORDERED_CARTS_TABLE." WHERE orderID=".$result[0]."") or die(db_error());
		while ($row = db_fetch_row($q))
		{		
			if ($row[0] == ADMIN_DISCOUNT_STRING)
			{
			    $total -= $row[1]*$row[2];

			    $row[4] = "<b>".show_price($row[1]*$row[2])."</b>";
			    $row[0] = "<b>".$row[0]."</b>";
			    $row[1] = "";
			    $row[2] = "";
			    $res[] = Array();
			    $res[] = $row;
			}
			else
			{
			    $total += $row[1]*$row[2];

			    $row[4] = show_price($row[1]*$row[2]);
			    $row[1] = show_price($row[1]);
			    $res[] = $row;
			}	
		}

		$result[8] = show_price($total); //order value

		$smarty->assign("orderer", $result);
		$smarty->assign("order", $res);

		$smarty->assign("main_content_template", "order_place.tpl.html");
	}
	else if (isset($_POST["complete_order"])) //place order
	{

		//shopping cart items count
		$c = 0;
		if (isset($_SESSION["gids"]))
			for ($j=0; $j<count($_SESSION["gids"]); $j++)
				for ($k=0; $k<5; $k++)
					if ($_SESSION["gids"][$j]) $c += $_SESSION["counts"][$j][$k];

		//not empty?
		if (isset($_SESSION["gids"]) && $c)
		{
			//insert order into database

		           if (preg_match('/^[\s0-9-()+]+$/',$_POST["phone"])) $post_phone = $_POST["phone"]; else $post_phone = mysql_real_escape_string($_POST["phone"]);
 		           if (preg_match('/[.+a-zA-Z0-9_-]+@[a-zA-Z0-9-]+.[a-zA-Z]+/',$_POST["email"])) $post_email = $_POST["email"]; else $post_email = mysql_real_escape_string($_POST["email"]);

 		           db_query("insert into ".ORDERS_TABLE." (order_time, cust_firstname, cust_lastname, cust_email, cust_country, cust_zip, cust_state, cust_city, cust_address, cust_phone, comment) values ('".get_current_time()."','".mysql_real_escape_string($_POST["first_name"])."','".mysql_real_escape_string($_POST["last_name"])."','".$post_email."','".mysql_real_escape_string($_POST["country"])."','".mysql_real_escape_string($_POST["zip"])."','".mysql_real_escape_string($_POST["state"])."','".mysql_real_escape_string($_POST["city"])."','".mysql_real_escape_string($_POST["address"])."','".$post_phone."','".$_POST["comment"]."');") or die (db_error());
  		           $oid = db_insert_id(); //order ID

			//now move shopping cart content to the database

			$k = 0; //total cart value
			$products = array();
			$adm = ""; //order notification for administrator

			for ($i=0; $i<count($_SESSION["gids"]); $i++)
			  if ($_SESSION["gids"][$i])
			  {
				$q = db_query("SELECT name, Price, product_code, hurl, categoryID FROM ".PRODUCTS_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
				if ($r = db_fetch_row($q))
				{
					$qprice = db_query("SELECT Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable FROM ".CHARACTER_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
					$rprice = db_fetch_row($qprice);
					
					$cr1pr = $_SESSION["gids"][$i][1]; //��� �������
					$cr2pr = $_SESSION["gids"][$i][2]+6; //��� �������
					$cr3pr = $_SESSION["gids"][$i][3]+8; //��� ���������
					$cr4pr = $_SESSION["gids"][$i][4]+12; //��� �������

					//product info
					$tmp = array(
						$_SESSION["gids"][$i][0], 	// 0 id
						$r[0], 				// 1 name
						$_SESSION["counts"][$i][0],	// 2 quantity
						$rprice[$cr1pr], 		// 3 cost
						$r[2], 				// 4 product_code
						$_SESSION["gids"][$i][1], 	// 5 character1
						$_SESSION["gids"][$i][2], 	// 6 character2
						$rprice[$cr2pr], 		// 7 character2price
						$_SESSION["gids"][$i][3], 	// 8 character3
						$rprice[$cr3pr], 		// 9 character3price
						$_SESSION["gids"][$i][4], 	// 10 character4
						$rprice[$cr4pr], 		// 11 character4price
						$_SESSION["counts"][$i][2], 	// 12 character2count
						$_SESSION["counts"][$i][3], 	// 13 character3count
						$_SESSION["counts"][$i][4],	// 14 character4count
						$r[4],				// 15 categoryID
						$rprice[15]
							);

					//store ordered products info into database
					$articul = trim($tmp[4]) ? "[".$tmp[4]."] " : "";
					

					if ($tmp[16]>0)
					{
					switch($tmp[5]) {
						case 1: $character1=ADMIN_PRODUCT_CHARACTER1_1; break;
						case 2: $character1=ADMIN_PRODUCT_CHARACTER1_2; break;
						case 3: $character1=ADMIN_PRODUCT_CHARACTER1_3; break;
						case 4: $character1=ADMIN_PRODUCT_CHARACTER1_4; break;
						case 5: $character1=ADMIN_PRODUCT_CHARACTER1_5; break;
						case 6: $character1=ADMIN_PRODUCT_CHARACTER1_6; break;
						case 7: $character1=ADMIN_PRODUCT_CHARACTER1_7; break;
							}


					switch($tmp[6]) {
						case 1: $character2=ADMIN_PRODUCT_CHARACTER2_DESC." (".ADMIN_PRODUCT_CHARACTER2_1.")"; break;
						case 2: $character2=ADMIN_PRODUCT_CHARACTER2_DESC." (".ADMIN_PRODUCT_CHARACTER2_2.")"; break;
							}
					switch($tmp[8]) {
						case 1: $character3=ADMIN_PRODUCT_CHARACTER3_DESC." (".ADMIN_PRODUCT_CHARACTER3_1.")"; break;
						case 2: $character3=ADMIN_PRODUCT_CHARACTER3_DESC." (".ADMIN_PRODUCT_CHARACTER3_2.")"; break;
						case 3: $character3=ADMIN_PRODUCT_CHARACTER3_DESC." (".ADMIN_PRODUCT_CHARACTER3_3.")"; break;
						case 4: $character3=ADMIN_PRODUCT_CHARACTER3_DESC." (".ADMIN_PRODUCT_CHARACTER3_4.")"; break;
							}
					switch($tmp[10]) {
						case 1: $character4=ADMIN_PRODUCT_CHARACTER4_DESC." (".ADMIN_PRODUCT_CHARACTER4_1.")"; break;
						case 2: $character4=ADMIN_PRODUCT_CHARACTER4_DESC." (".ADMIN_PRODUCT_CHARACTER4_2.")"; break;
							}
					}

					$q1=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."p".$tmp[5].$i."', '".$articul.$tmp[1]." ".$character1."', '".$tmp[3]."', '".$tmp[2]."');") or die (db_error());
					if (($tmp[12]>0) && ($tmp[16]>0)) {$q2=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."p".$tmp[5]."k".$tmp[6]."', '".$articul.$character2."', '".$tmp[7]."', '".$tmp[12]."');") or die (db_error());}
					if (($tmp[13]>0) && ($tmp[16]>0)) {$q3=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."p".$tmp[5]."n".$tmp[8]."', '".$articul.$character3."', '".$tmp[9]."', '".$tmp[13]."');") or die (db_error());}
					if (($tmp[14]>0) && ($tmp[16]>0)) {$q4=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."p".$tmp[5]."d".$tmp[10]."', '".$articul.$character4."', '".$tmp[11]."', '".$tmp[14]."');") or die (db_error());}

					//update item sold
					$q = db_query("SELECT items_sold, in_stock FROM ".PRODUCTS_TABLE." WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());
					$row = db_fetch_row($q);
					$i_s = $row[0]+1;
					$i_c = $row[1]-$tmp[2];
					db_query("UPDATE ".PRODUCTS_TABLE." SET items_sold='".$i_s."', in_stock='".$i_c."' WHERE productID='".$_SESSION["gids"][$i][0]."'") or die (db_error());					

					$products[] = $tmp;

					//update order amount
					$k += $_SESSION["counts"][$i][0]*$rprice[$cr1pr]+$_SESSION["counts"][$i][2]*$rprice[$cr2pr]+$_SESSION["counts"][$i][3]*$rprice[$cr3pr]+$_SESSION["counts"][$i][4]*$rprice[$cr4pr];

					//order notification for administrator - update
					$adm .= $articul.$tmp[1]." ".$character1."; ".TABLE_PRODUCT_COST." - ".$tmp[3]."; ".TABLE_PRODUCT_QUANTITY." - ".$tmp[2]."; ".TABLE_PRODUCT_SUMM." - ".$tmp[3]*$tmp[2]."\n";
					if ($tmp[12]>0) {$adm .= $articul.$character2."; ".TABLE_PRODUCT_COST." - ".$tmp[7]."; ".TABLE_PRODUCT_QUANTITY." - ".$tmp[12]."; ".TABLE_PRODUCT_SUMM." - ".$tmp[7]*$tmp[12]."\n";}
					if ($tmp[13]>0) {$adm .= $articul.$character3."; ".TABLE_PRODUCT_COST." - ".$tmp[9]."; ".TABLE_PRODUCT_QUANTITY." - ".$tmp[13]."; ".TABLE_PRODUCT_SUMM." - ".$tmp[9]*$tmp[13]."\n";}
					if ($tmp[14]>0) {$adm .= $articul.$character4."; ".TABLE_PRODUCT_COST." - ".$tmp[11]."; ".TABLE_PRODUCT_QUANTITY." - ".$tmp[14]."; ".TABLE_PRODUCT_SUMM." - ".$tmp[11]*$tmp[14]."\n";}
					$adm .= "\n";
				}
			  }

			if (isset($_SESSION["present"])) 
			  {
			    $q1=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$_SESSION["present"][2]."', '".$_SESSION["present"][1]."', '0', '1');") or die (db_error());	   
			  }

			if (isset($_SESSION["minimal"])) 
			  {
			    $q1=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."min01"."', '".$_SESSION["minimal"][0]."', '".$_SESSION["minimal"][1]."', '1');") or die (db_error());
			    $k += $_SESSION["minimal"][1];
			  }

			if (isset($_SESSION["discount"])) 
			  {
			    $q1=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."dis01"."', '".ADMIN_DISCOUNT_STRING."', '".$_SESSION["discount"]."', '1');") or die (db_error());
			    $k -= $_SESSION["discount"];
			  }

			if (isset($_SESSION["get_fast_order"])) 
			  {
			    $q1=db_query("insert into ".ORDERED_CARTS_TABLE." (orderID, productID, name, Price, Quantity) values ('$oid', '".$tmp[0]."fst01"."', '".ADMIN_FAST_ORDER."', '".$_SESSION["get_fast_order"]."', '1');") or die (db_error());
			    $k += $_SESSION["get_fast_order"];
			  }

			//assign order content to smarty
			$smarty_mail->assign("order_content", $products);
			$smarty_mail->assign("order_total", $k." ".$currency_iso_3);
			$smarty_mail->assign("order_id", $oid);
			$smarty_mail->assign("order_custname", $_POST["first_name"]." ".$_POST["last_name"]);
			$smarty_mail->assign("order_shipping_address", "�.".$_POST["city"]."\n".$_POST["address"]); //."\n�.".." ".$_POST["state"]."  ".$_POST["zip"]."\n".$_POST["country"]
			if (isset($_SESSION["present"])) {$smarty_mail->assign("present", $_SESSION["present"]);}
			if (isset($_SESSION["minimal"])) {$smarty_mail->assign("minimal", $_SESSION["minimal"]);}
			if (isset($_SESSION["discount"])) {$smarty_mail->assign("discount", $_SESSION["discount"]);}
			if (isset($_SESSION["get_fast_order"])) {$smarty_mail->assign("get_fast_order", $_SESSION["get_fast_order"]);}

			$_SESSION["order_id"] = $oid;
			//$_SESSION["order_amount"] = $k;

			//send message to customer
			$file_name = "./css/css_".CONF_COLOR_SCHEME."/image/mail_logo.jpg";

			$To = "=?".DEFAULT_CHARSET."?B?".base64_encode($_POST["first_name"]." ".$_POST["last_name"])."?=<".$_POST["email"].">";
			$Subject = "=?".DEFAULT_CHARSET."?B?".base64_encode(EMAIL_CUSTOMER_ORDER_NOTIFICATION_SUBJECT)."?=";
			$From = "=?".DEFAULT_CHARSET."?B?".base64_encode(CONF_SHOP_NAME)."?=<".CONF_GENERAL_EMAIL.">";

			$bound = "message-bound";
			$headers = "From: ".$From."\n";
			$headers .= "Return-path: <".CONF_GENERAL_EMAIL.">"."\n";
			$headers .= "Mime-Version: 1.0n"."\n";
			$headers .= "Content-Type: multipart/related; boundary=".'"'.$bound.'"'."\n";

			$html_body = $smarty_mail->fetch("order_notification.tpl.html");

			$body = "--$bound\n";
			$body .= "Content-type: text/html; charset=\"".DEFAULT_CHARSET."\"\n";
			$body .= "Content-Transfer-Encoding: 8bit\n\n";
			$body .= $html_body;
			$body .= "\n\n--$bound\n";



			$body .= "Content-Type: image/jpeg; name=\"".basename($file_name)."\"\n";
			$body .= "Content-Transfer-Encoding:base64\n";
			$body .= "Content-ID: <mail_img_1>\n\n";
			$f = fopen($file_name,"rb");
			$body .= base64_encode(fread($f,filesize($file_name)))."\n";
			$body .= "--$bound--\n\n";

			mail($To, $Subject, $body, $headers);


			$To_Admin = "=?".DEFAULT_CHARSET."?B?".base64_encode(CONF_ORDERS_EMAIL)."?=<".CONF_ORDERS_EMAIL.">";
			$Subject_Admin = "=?".DEFAULT_CHARSET."?B?".base64_encode(EMAIL_ADMIN_ORDER_NOTIFICATION_SUBJECT)."?=";
			$From_Admin = "=?".DEFAULT_CHARSET."?B?".base64_encode(CONF_SHOP_NAME)."?=<".CONF_GENERAL_EMAIL.">";

			//notification for administrator
			$od = STRING_ORDER_ID.": $oid\n\n";
			if (isset($_SESSION["present"]) && $_SESSION["present"][1]) {$adm .= $_SESSION["present"][1]." ".STRING_PRESENT."\n\n";}
			if (isset($_SESSION["minimal"])) {$adm .= $_SESSION["minimal"][0]." ".$_SESSION["minimal"][1].CONF_CURRENCY_ID_RIGHT."\n\n";}
			if (isset($_SESSION["discount"])) {$adm .= ADMIN_DISCOUNT_STRING." ".$_SESSION["discount"].CONF_CURRENCY_ID_RIGHT."\n\n";}
			if (isset($_SESSION["get_fast_order"])) {$adm .= ADMIN_FAST_ORDER." ".$_SESSION["get_fast_order"].CONF_CURRENCY_ID_RIGHT."\n\n";}
			$adm .= "����������� ���������:"."\n".$_POST["comment"]."\n";
			$adm .= "\n".CUSTOMER_FIRST_NAME." ".$_POST["first_name"]."\n".CUSTOMER_LAST_NAME." ".$_POST["last_name"]."\n".CUSTOMER_ADDRESS.": ".$_POST["country"].", ".$_POST["zip"].", ".$_POST["state"].",  ".$_POST["city"].", ".$_POST["address"]."\n".CUSTOMER_PHONE_NUMBER.": ".$_POST["phone"]."\n".CUSTOMER_EMAIL.": ".$_POST["email"];
			mail($To_Admin, $Subject_Admin, $od.$adm, "From: ".$From_Admin."\n".stripslashes(EMAIL_MESSAGE_PARAMETERS)."\nReturn-path: <".CONF_GENERAL_EMAIL.">");

			unset($_SESSION["gids"]);
			unset($_SESSION["counts"]);
			unset($_SESSION["present"]);
			unset($_SESSION["minimal"]);
			unset($_SESSION["discount"]);
			unset($_SESSION["get_fast_order"]);

			//show order placement result
			header("Location: index.php?order_placement_result=1");

		}
		else //empty shopping cart
		{
			header("Location: index.php?shopping_cart=yes");
		}
	}

?>