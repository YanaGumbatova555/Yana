<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// auxiliary information page presentation

	if (isset($_GET["aux_page"]))
	{
		if (strstr($_GET["aux_page"],"aux") && file_exists("./cfg/".$_GET["aux_page"]))
		{	
			$out = Array();
			$f = file("./cfg/".$_GET["aux_page"]);
			$i = 0;
			while ($i<count($f))
				{
				$r = 0;
				if (strpos($f[$i], 'title')) {$smarty->assign("aux_title", str_replace("/title/","",$f[$i])); $r = 1;}
   				if (strpos($f[$i], 'meta-t')) {$smarty->assign("meta_title", str_replace("/meta-t/","",$f[$i]));$r = 1;}
   				if (strpos($f[$i], 'meta-k')) {$smarty->assign("meta_keywords", str_replace("/meta-k/","",$f[$i]));$r = 1;}
   				if (strpos($f[$i], 'meta-d')) {$smarty->assign("meta_desc", str_replace("/meta-d/","",$f[$i]));$r = 1;}
				if ($r == 0) {$out[] = $f[$i];}
				$i++;
				}

			if ($out != "") $aux_text = implode("", $out);

			$smarty->assign("auxiliary_page", $aux_text);
		}
		$smarty->assign("main_content_template", "aux_page.tpl.html");
	}

?>