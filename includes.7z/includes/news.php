<?php
/****************************************************************************
 *                                                                                         *
 * Shop-Script FREE                                                                    *
 * Copyright (c) 2005 Supme. Modify Mihbel. All rights reserved.                           *
 *                                                                                         *
 ****************************************************************************/
if (isset($_GET["news"]))    
    if ($_GET["news"])

    {
	//calculate a path
	$path = Array();

	$row[0] = "index.php?news";
	$row[1] = ADMIN_NEWS;
	$path[] = $row;

        $p = array();
        $q = db_query("SELECT title, text, date, brief, Pict, enable, meta_title, meta_keywords, meta_desc FROM ".NEWS_TABLE." WHERE id='".mysql_real_escape_string($_GET["news"])."'") or die (db_error());
        $p = mysql_fetch_row($q);

	$row[0] = "index.php?news=".$_GET["news"];
	$row[1] = $p[0];
	$path[] = $row;

	$smarty->assign("product_category_path",$path);

	$smarty->assign("meta_title", $p[6]);
	$smarty->assign("meta_keywords", $p[7]);
	$smarty->assign("meta_desc", $p[8]);
        $smarty->assign("newstext", $p);
        $smarty->assign("main_content_template", "news.tpl.html");
    }
    else
    {
	//calculate a path
	$path = Array();
	$row[0] = "index.php?news";
	$row[1] = ADMIN_NEWS;
	$path[] = $row;

	$smarty->assign("product_category_path",$path);

        $q = db_query("SELECT id, title, date, brief, Pict, enable FROM ".NEWS_TABLE." ") or die (db_error());
        $i=0;
        $news=array();
        while ($p=mysql_fetch_row($q))
            { 
                $news[$i] = $p;
                $i++;
             }
        $smarty->assign("newslist", $news);
        $smarty->assign("main_content_template", "news.tpl.html");
    }
?>