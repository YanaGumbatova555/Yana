<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/
	//show all products of selected category

	if (isset($categoryID) && !isset($productID) && $categoryID)
	{
		//get selected category info
		$q = db_query("SELECT categoryID, name, description, picture, meta_title, meta_keywords, meta_desc  FROM ".CATEGORIES_TABLE." WHERE categoryID='$categoryID'") or die (db_error());
		$row = db_fetch_row($q);
		if ($row)
		{
			if (!file_exists("./products_pictures/".$row[3])) $row[3] = "";
			$smarty->assign("selected_category", $row);
			$smarty->assign("meta_title", $row[4]);
			$smarty->assign("meta_keywords", $row[5]);
			$smarty->assign("meta_desc", $row[6]);
		}
		else
		{
			//category not found
			header("Location: index.php");
		}

		$smarty->assign("main_content_template", "category.tpl.html");

		//calculate a path to the category
		$path = array();
		$curr = $categoryID;
		do
		{
			$q = db_query("SELECT parent, name, hurl FROM ".CATEGORIES_TABLE." WHERE categoryID='$curr'") or die (db_error());
			$row = db_fetch_row($q);
			if ($row[2] != "") {$tmp = "catalog/".$row[2];} else {$tmp = "index.php?categoryID=".$curr;}

			$curr = $row[0]; //get parent ID
			$row[0] = $tmp;
			$path[] = $row;

		} while ($curr);
		//now reverse $path
		$path = array_reverse($path);

		$smarty->assign("product_category_path",$path);

		//show subcategories
		$q = db_query("SELECT categoryID, name, products_count FROM ".CATEGORIES_TABLE." WHERE parent='$categoryID' ORDER BY ".CONF_SORT_CATEGORY." ".CONF_SORT_CATEGORY_BY) or die (db_error());
		$result = array();
		while ($row = db_fetch_row($q))
		{
			$result[] = $row;
		}
		$smarty->assign("subcategories_to_be_shown",$result);

		//show active products
		$q = db_query("SELECT count(*) FROM ".PRODUCTS_TABLE." WHERE categoryID='$categoryID' AND enabled=1 ORDER BY ".$_SESSION["sort"]." ".$_SESSION["order"]) or die (db_error());
		$g_count = db_fetch_row($q);
		$g_count = $g_count[0];

		$smarty->assign("catalog_navigator", NULL);
		$smarty->assign("products_to_show", NULL);
		$smarty->assign("products_to_show_count",NULL);

		if ($g_count) // there are products in the category
		{
			if ($offset > $g_count) $offset=0;
			$q = db_query("SELECT categoryID, ".PRODUCTS_TABLE.".name, brief_description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, big_picture, list_price, productID, product_code, hurl, items_sold, ".PRODUCTS_TABLE.".brandID, ".BRAND_TABLE.".name FROM ".PRODUCTS_TABLE." LEFT JOIN ".BRAND_TABLE." USING(brandID) WHERE categoryID='".$categoryID."' AND enabled=1 ORDER BY ".PRODUCTS_TABLE.".".$_SESSION["sort"]." ".$_SESSION["order"]) or die (db_error());

			//fetch all products
			$result = array();
			$i=0;
			while ($row = db_fetch_row($q))
			{
				if (isset($_GET["show_all"]) || ($i>=$offset && $i<$offset+CONF_PRODUCTS_PER_PAGE))
				{
					//update several product fields
					if (!file_exists("./products_pictures/".$row[9])) $row[9] = 0;
					if (!file_exists("./products_pictures/".$row[7])) $row[7] = 0;
					if (!file_exists("./products_pictures/".$row[5])) $row[5] = 0;

					$row[17] = show_price($row[4]);
					$row[18] = show_price($row[10]);
					$row[19] = show_price($row[10]-$row[4]); //you save (value)
					if ($row[10]) $row[20] = ceil(((($row[10]-$row[4])/$row[10])*100)); //you save (%)
					$row[21]= round($row[4]/CURR_USD);  //usd
					$row[22]= round($row[4]/CURR_EUR);  //eur

					if (($row[6] > 0) && (CONF_SHOW_ADD2CART > 0)) {$row[23]=1;}
					else 
					  if ((CONF_SHOW_ADD2CART_INSTOCK > 0) && (CONF_SHOW_ADD2CART > 0))
						{$row[23]=1;}
					  else {$row[23]=0;}

					if ($row[6] > 0) 
					    $result[] = $row;
					else 
					    if (CONF_SHOW_PRODUCT_INSTOCK > 0) {$result[] = $row;}
				}
				$i++;
			}
			//number of products to show on this page
			if (!isset($_GET["show_all"]))
			{
				$min = CONF_PRODUCTS_PER_PAGE;
				if ($min > $g_count-$offset) $min = $g_count-$offset;
			}
			else
			{
				$min = $g_count;
				$offset = "show_all";
			}

			$smarty->assign("products_to_show", $result);
			$smarty->assign("products_to_show_count", $min);

			$navigator = ""; //navigation links
			showNavigator($g_count, $offset, CONF_PRODUCTS_PER_PAGE, "index.php?categoryID=$categoryID&amp;sort_by=".$_GET["sort_by"]."&amp;",$navigator);
			$smarty->assign("catalog_navigator", $navigator);
		}
		else if (CONF_SHOW_BEST_CHOICE == 1) //there are no items in the category. search for items in it's subcategories if CONF_SHOW_BEST_CHOICE is set
		{
			//are there sub categories?
			$q = db_query("SELECT count(*) FROM ".CATEGORIES_TABLE." WHERE parent='$categoryID'") or die (db_error());
			$row = db_fetch_row($q);
			if ($row[0]) //there are
			{
				//create a query for extracting products from subcategories
				$s = "SELECT categoryID, ".PRODUCTS_TABLE.".name, brief_description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, big_picture, list_price, productID, product_code, hurl, items_sold, ".PRODUCTS_TABLE.".brandID, ".BRAND_TABLE.".name FROM ".PRODUCTS_TABLE." LEFT JOIN ".BRAND_TABLE." USING(brandID) WHERE enabled=1";

				$a = get_Subs($categoryID);
				if (count($a) > 0)
				{ 
					$s.= " AND (categoryID=$a[0]";

					for ($i=1;$i<count($a);$i++)
					{
						$s.=" OR categoryID=$a[$i]";
					}
					$s.= ")";
				}

				$q = db_query($s." ORDER BY ".PRODUCTS_TABLE.".".$_SESSION["sort"]." ".$_SESSION["order"]) or die (db_error());

				$cnt = mysql_num_rows($q);

				if ($cnt) //there are products in the subcategories
				{

					$i=0;
					$result = array();
					while ($row = db_fetch_row($q))
					{
					if (isset($_GET["show_all"]) || ($i>=$offset && $i<$offset+CONF_PRODUCTS_PER_PAGE))
						{

						//update several product fields
						if (!file_exists("./products_pictures/".$row[5])) $row[5] = 0;
						if (!file_exists("./products_pictures/".$row[7])) $row[7] = 0;
						if (!file_exists("./products_pictures/".$row[9])) $row[9] = 0;

						$row[17] = show_price($row[4]);
						$row[18] = show_price($row[10]);
						$row[19] = show_price($row[10]-$row[4]); //you save (value)
						if ($row[10]) $row[20] = ceil(((($row[10]-$row[4])/$row[10])*100)); //you save (%)
						$row[21]= round($row[4]/CURR_USD);  //usd
						$row[22]= round($row[4]/CURR_EUR);  //eur

						if (($row[6] > 0) && (CONF_SHOW_ADD2CART > 0)) {$row[23]=1;}
						else 
					    	  if ((CONF_SHOW_ADD2CART_INSTOCK > 0) && (CONF_SHOW_ADD2CART > 0))
							{$row[23]=1;}
					    	  else {$row[23]=0;}

						if ($row[6] > 0) 
						    $result[] = $row;
						else 
						    if (CONF_SHOW_PRODUCT_INSTOCK > 0) {$result[] = $row;}
						}
						$i++;
					}
				
					//number of products to show on this page
					if (!isset($_GET["show_all"]))
					{
						$min = CONF_PRODUCTS_PER_PAGE;
						if ($min > $cnt-$offset) $min = $cnt-$offset;
					}
					else
					{
						$min = $cnt;
						$offset = "show_all";
					}
				
					$smarty->assign("products_to_show", $result);
					$smarty->assign("products_to_show_count", $min);

					$navigator = ""; //navigation links

					//if ($path[0][2]) {$nav_path = "catalog/".$path[0][2];} else {$nav_path = "index.php?categoryID=$categoryID&offset=";}

					showNavigator($cnt, $offset, CONF_PRODUCTS_PER_PAGE, "index.php?categoryID=$categoryID&amp;" ,$navigator);
					$smarty->assign("catalog_navigator", $navigator);

					$smarty->assign("products_to_show_best_choice", min($cnt, CONF_PRODUCTS_PER_PAGE));
				}
			}

		}

	}
?>