<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	db_query("DROP TABLE IF EXISTS ".ORDERS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".ORDERED_CARTS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".PRODUCTS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".CATEGORIES_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".SPECIAL_OFFERS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".TAGS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".PAGES_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".NEWS_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".CHARACTER_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".THUMB_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".PRESENT_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".REVIEW_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".BRAND_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".VOTES_TABLE.";") or die (db_error());
	db_query("DROP TABLE IF EXISTS ".VOTES_CONTENT_TABLE.";") or die (db_error());

	db_query("CREATE TABLE ".ORDERS_TABLE." (orderID INT PRIMARY KEY AUTO_INCREMENT, order_time DATETIME, cust_firstname VARCHAR(30), cust_lastname VARCHAR(30), cust_email VARCHAR(30), cust_country VARCHAR(30), cust_zip VARCHAR(30), cust_state VARCHAR(30), cust_city VARCHAR(30), cust_address VARCHAR(30), cust_phone VARCHAR(30), status INT, comment TEXT) CHARACTER SET cp1251 COLLATE cp1251_general_ci;") or die (db_error());
	db_query("CREATE TABLE ".ORDERED_CARTS_TABLE." (productID VARCHAR(20) NOT NULL, orderID INT NOT NULL, name CHAR(255), Price FLOAT, Quantity FLOAT, PRIMARY KEY (productID, orderID)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".PRODUCTS_TABLE." (productID INT PRIMARY KEY AUTO_INCREMENT, categoryID INT, name VARCHAR(255), description TEXT, customers_rating FLOAT NOT NULL, Price FLOAT, picture VARCHAR(30), in_stock INT, thumbnail VARCHAR(30), customer_votes INT NOT NULL, items_sold INT NOT NULL, big_picture VARCHAR(30), enabled INT NOT NULL, brief_description TEXT, list_price FLOAT, product_code CHAR(25), hurl VARCHAR (255), accompanyID VARCHAR(150), brandID INT (11) DEFAULT NULL, meta_title VARCHAR(255), meta_keywords VARCHAR(255), meta_desc VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".CATEGORIES_TABLE." (categoryID INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255), parent INT, products_count INT, description TEXT, picture VARCHAR(30), products_count_admin INT, about TEXT, enabled INT, meta_title VARCHAR(255), meta_keywords VARCHAR(255), meta_desc VARCHAR(255), hurl VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".SPECIAL_OFFERS_TABLE." (offerID INT PRIMARY KEY AUTO_INCREMENT, productID INT, sort_order INT) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".TAGS_TABLE." (id INT NOT NULL AUTO_INCREMENT, pid INT (11) DEFAULT NULL, tag VARCHAR (30) DEFAULT NULL, hurl VARCHAR (255), PRIMARY KEY (id)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".PAGES_TABLE." (id INT PRIMARY KEY AUTO_INCREMENT, date DATE NOT NULL, title TEXT, text TEXT, brief TEXT, Pict VARCHAR(50), enable INT, meta_title VARCHAR(255), meta_keywords VARCHAR(255), meta_desc VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".NEWS_TABLE." (id INT PRIMARY KEY AUTO_INCREMENT, date DATE NOT NULL, title TEXT, text TEXT, brief TEXT, Pict VARCHAR(50), enable INT, meta_title VARCHAR(255), meta_keywords VARCHAR(255), meta_desc VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".CHARACTER_TABLE." (productID INT NOT NULL, Prdct1 FLOAT, Prdct2 FLOAT, Prdct3 FLOAT, Prdct4 FLOAT, Prdct5 FLOAT, Prdct6 FLOAT, Prdct7 FLOAT, Crtr1 FLOAT, Crtr2 FLOAT, Crtr3 FLOAT, Crtr4 FLOAT, Crtr5 FLOAT, Crtr6 FLOAT, Crtr7 FLOAT, Crtr8 FLOAT, enable INT) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".THUMB_TABLE." (productID INT NOT NULL, picture VARCHAR(150), description VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".PRESENT_TABLE." (presentID INT NOT NULL AUTO_INCREMENT, productID INT (11), value FLOAT, PRIMARY KEY (presentID)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".REVIEW_TABLE." (reviewID INT PRIMARY KEY AUTO_INCREMENT, productID INT (11), username VARCHAR(50), email VARCHAR(50), review TEXT, date_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".BRAND_TABLE." (brandID INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(150), comment VARCHAR(50), Pict VARCHAR(30), description TEXT, brief TEXT, meta_title VARCHAR(255), meta_keywords VARCHAR(255), meta_desc VARCHAR(255)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".VOTES_TABLE." (votesID INT PRIMARY KEY AUTO_INCREMENT, title VARCHAR(50), enable INT(11)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
	db_query("CREATE TABLE ".VOTES_CONTENT_TABLE." (votesID INT, ID INT PRIMARY KEY AUTO_INCREMENT, question VARCHAR(50), result INT(11)) CHARACTER SET cp1251 COLLATE cp1251_general_ci") or die (db_error());
?>