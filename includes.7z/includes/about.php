<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 Supme. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// auxiliary information page presentation

	if (isset($_GET["about"]))
	{
		if ($_GET["category"])
			{
			$q = db_query("SELECT categoryID, name, about, meta_title, meta_keywords, meta_desc FROM ".CATEGORIES_TABLE." WHERE categoryID='".mysql_real_escape_string($_GET["category"])."'") or die (db_error());
			$p = db_fetch_row($q);

			$smarty->assign("title", $p[1]);
			$smarty->assign("meta_title", $p[3]);
			$smarty->assign("meta_keywords", $p[4]);
			$smarty->assign("meta_desc", $p[5]);
			if ($p[2]<>"") {$smarty->assign("about", $p[2]);} else {$smarty->assign("about", NO_ABOUT);}
			}
		if ($_GET["brand"])
			{
			$q = db_query("SELECT brandID, name, description, meta_title, meta_keywords, meta_desc FROM ".BRAND_TABLE." WHERE brandID='".mysql_real_escape_string($_GET["brand"])."'") or die (db_error());
			$p = db_fetch_row($q);

			$smarty->assign("title", $p[1]);
			$smarty->assign("meta_title", $p[3]);
			$smarty->assign("meta_keywords", $p[4]);
			$smarty->assign("meta_desc", $p[5]);
			if ($p[2]<>"") {$smarty->assign("about", $p[2]);} else {$smarty->assign("about", NO_ABOUT);}
			}

		$smarty->assign("main_content_template", "about.tpl.html");
	}
?>