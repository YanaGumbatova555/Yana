<?php
	$q = db_query("SELECT productID, ".PRODUCTS_TABLE.".name, Price, ".PRODUCTS_TABLE.".picture, items_sold, ".PRODUCTS_TABLE.".hurl, ".CATEGORIES_TABLE.".enabled FROM ".PRODUCTS_TABLE." RIGHT JOIN ".CATEGORIES_TABLE." USING (categoryID) WHERE ".PRODUCTS_TABLE.".enabled=1 AND ".CATEGORIES_TABLE.".enabled=1 ORDER BY items_sold DESC") or die (db_error());

	$result = Array();
        while ($row = db_fetch_row($q))
	  {
		if (!file_exists("./products_pictures/".$row[3])) {$row[3] = "";}
		$row[6] = show_price($row[2]);
		$row[7]= round($row[2]/CURR_USD);  //usd
		$row[8]= round($row[2]/CURR_EUR);  //eur
		if ($row[3] != "") $result[] = $row;
	  }

	$smarty->assign("hits_to_show", $result);
?>
