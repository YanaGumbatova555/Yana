<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//products and categories tree view

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}
	//show new orders page if selected
	if (!strcmp($sub, "categories"))
	{
		if (isset($_POST["categories_update"])) { //save changes in current category

		// on/off

		$q = db_query("SELECT categoryID FROM ".CATEGORIES_TABLE." ") or die (db_error());
		$i=0;
		while ($row=mysql_fetch_array($q))
		  {
			if (!isset($_POST["category_".$row[0]])) $category_enable = 0;
			if (!strcmp($_POST["category_".$row[0]], "on")) $category_enable = 1;
			else $category_enable = 0;

				db_query("UPDATE ".CATEGORIES_TABLE." SET enabled='".$category_enable."' WHERE categoryID='".$row[0]."'");
			$i++;
		  }


		header("Location: admin.php?dpt=catalog&sub=categories");

		}





		if (isset($_GET["del"]) && isset($_GET["c_id"])) //delete category
		{

			//photo
			$q = db_query("SELECT picture FROM ".CATEGORIES_TABLE." WHERE categoryID='".$_GET["c_id"]."' and categoryID<>0") or die (db_error());
			$r = db_fetch_row($q);
			if ($r[0] && file_exists("./products_pictures/$r[0]")) unlink("./products_pictures/$r[0]");

			//delete from db
			$q = db_query("DELETE FROM ".CATEGORIES_TABLE." WHERE categoryID='".$_GET["c_id"]."' and categoryID<>0") or die (db_error());

			deleteSubCategories($_GET["c_id"]);

			update_products_Count_Value_For_Categories(0);

			header("Location: admin.php?dpt=catalog&sub=categories");
		}


		//calculate how many products are there in the root category
		$q = db_query("SELECT count(*) FROM ".PRODUCTS_TABLE." WHERE categoryID=0") or die (db_error());
		$cnt = db_fetch_row($q);
		$smarty->assign("products_in_root_category",$cnt[0]);


		//create a category tree
		$c = fillTheCList(0,0);
		$smarty->assign("categories", $c);


		//set main template
		$smarty->assign("admin_sub_dpt", "catalog_categories.tpl.html");
	}

?>