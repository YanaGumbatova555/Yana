<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/
	//products edit

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!isset($_GET["productID"])) $_GET["productID"] = 0;

	if (!strcmp($sub, "products_edit"))
	{

	   if (isset($_POST["save_product"])) //save item to the database
	   {
		if (!isset($_POST["price"]) || !$_POST["price"] || $_POST["price"] < 0)
			$_POST["price"] = 0; //price can not be negative
		if (!isset($_POST["name"]) || trim($_POST["name"])=="") $_POST["name"] = "not defined";
		if (isset($_POST["in_stock"]) && ($_POST["in_stock"]<>"")) {$instock = $_POST["in_stock"];} else {$instock = 0;}

			if (!isset($_POST["enable_autores"])) $_POST["enable_autores"] = 0;
			if (!strcmp($_POST["enable_autores"], "on")) $_POST["enable_autores"] = 1;
			else $_POST["enable_autores"] = 0;

			if (!isset($_POST["enable_character"])) $_POST["enable_character"] = 0;
			if (!strcmp($_POST["enable_character"], "on")) $_POST["enable_character"] = 1;
			else $_POST["enable_character"] = 0;


		if ($_POST["save_product"]) { //if $_POST["save_product"] != 0 then update item
			
			//delete old product photos if they're being replaced
			$q = db_query("SELECT picture, big_picture, thumbnail FROM ".PRODUCTS_TABLE." WHERE productID='".$_POST["save_product"]."' ORDER BY productID ASC") or die (db_error());
			$row = db_fetch_row($q);

			//generating query

			if ($_POST["hurl"]=="") {$new_hurl=to_url($_POST["name"])."_".$_POST["save_product"].".html";} else {$new_hurl=$_POST["hurl"];}

			$s = "UPDATE ".PRODUCTS_TABLE." SET categoryID='".$_POST["categoryID"]."', name='".rusDoubleQuotes($_POST["name"])."', Price='".$_POST["price"]."', description='".$_POST["description"]."', in_stock=".$instock.", customers_rating='".$_POST["rating"]."', brief_description='".$_POST["brief_description"]."', list_price='".$_POST["list_price"]."', product_code='".$_POST["product_code"]."', hurl='".$new_hurl."', accompanyID='".$_POST["accompany"]."', brandID='".$_POST["brand"]."', meta_title='".rusDoubleQuotes($_POST["meta_title"])."', meta_keywords='".rusDoubleQuotes($_POST["meta_keywords"])."', meta_desc='".rusDoubleQuotes($_POST["meta_desc"])."'";
			$s1 = "";


			//character

			//if (($_POST["enable_character"] == 0) && ($_POST["p_c0"] == 0)) {$_POST["p_c0"]=$_POST["price"];}

			if ($_POST["p_c0"] <> $_POST["price"]) {$_POST["p_c0"]=$_POST["price"];}

			$sc = "UPDATE ".CHARACTER_TABLE." SET Prdct1='".$_POST["p_c0"]."', Prdct2='".$_POST["p_c1"]."', Prdct3='".$_POST["p_c2"]."', Prdct4='".$_POST["p_c3"]."', Prdct5='".$_POST["p_c4"]."', Prdct6='".$_POST["p_c5"]."', Prdct7='".$_POST["p_c6"]."', Crtr1='".$_POST["p_c7"]."', Crtr2='".$_POST["p_c8"]."', Crtr3='".$_POST["p_c9"]."', Crtr4='".$_POST["p_c10"]."', Crtr5='".$_POST["p_c11"]."', Crtr6='".$_POST["p_c12"]."', Crtr7='".$_POST["p_c13"]."', Crtr8='".$_POST["p_c14"]."', enable='".$_POST["enable_character"]."'";
			$sc1 = "";

			//more pictures

			if (!($_FILES["thumb_pic"]["name"]==''))
			{
			$_FILES["thumb_pic"]["name"] = str_replace(" ","_",$_FILES["thumb_pic"]["name"]);
			$r = move_uploaded_file($_FILES["thumb_pic"]["tmp_name"], "./products_thumb/".$_FILES["thumb_pic"]["name"]);
			SetRightsToUploadedFile( "./products_thumb/".$_FILES["thumb_pic"]["name"] );

			img_resize("./products_thumb/".$_FILES["thumb_pic"]["name"], "./products_thumb/P_".$_FILES["thumb_pic"]["name"], 150, 150);

			
			$f = $_FILES["thumb_pic"]["name"];
			$d = $_POST["thumb_desc"];
			db_query("INSERT INTO ".THUMB_TABLE." (productID, picture, description) VALUES ('".$_POST["save_product"]."','".$f."','".$d."');") or die (db_error());
			}

			//old pictures?
			if (isset($_FILES["picture"]) && $_FILES["picture"]["name"])
			{
				//delete old picture
				if ($row[0] && file_exists("./products_pictures/".$row[0]))
					unlink("./products_pictures/".$row[0]);
				if ($row[0] && file_exists("./products_pictures/H_".$row[0]))
					unlink("./products_pictures/H_".$row[0]);
				if ($row[0] && file_exists("./products_pictures/H_".$row[0]))
					unlink("./products_pictures/SC_".$row[0]);

			}
			if (isset($_FILES["big_picture"]) && $_FILES["big_picture"]["name"])
			{
				//delete old picture
				if ($row[1] && file_exists("./products_pictures/".$row[1]))
					unlink("./products_pictures/".$row[1]);
			}
			if (isset($_FILES["thumbnail"]) && $_FILES["thumbnail"]["name"])
			{
				//delete old picture
				if ($row[2] && file_exists("./products_pictures/".$row[2]))
					unlink("./products_pictures/".$row[2]);
			}


			$pid = $_POST["save_product"];


		}
		else
		{
			//add new product
			
			db_query("INSERT INTO ".PRODUCTS_TABLE." (categoryID, name, description, customers_rating, Price, in_stock, customer_votes, items_sold, enabled, brief_description, list_price, product_code, picture, thumbnail, big_picture, hurl, accompanyID, brandID, meta_title, meta_keywords, meta_desc) VALUES ('".$_POST["categoryID"]."','".rusDoubleQuotes($_POST["name"])."','".$_POST["description"]."', 0, '".$_POST["price"]."', ".$instock.", 0, 0, 1, '".$_POST["brief_description"]."', '".$_POST["list_price"]."', '".$_POST["product_code"]."','','','','', '".$_POST["accompany"]."', '".$_POST["brand"]."', '".rusDoubleQuotes($_POST["meta_title"])."', '".rusDoubleQuotes($_POST["meta_keywords"])."', '".rusDoubleQuotes($_POST["meta_desc"])."');") or die (db_error());
			$pid = db_insert_id();
			if ($_POST["hurl"]=="") {$new_hurl=to_url($_POST["name"])."_".$pid.".html";} else {$new_hurl=$_POST["hurl"];}
			
			if (($_POST["enable_character"] == 0) && ($_POST["p_c0"] == 0)) {$_POST["p_c0"]=$_POST["price"];}
			db_query("INSERT INTO ".CHARACTER_TABLE." (productID, Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable) VALUES ('".$pid."', '".$_POST["p_c0"]."', '".$_POST["p_c1"]."', '".$_POST["p_c2"]."', '".$_POST["p_c3"]."', '".$_POST["p_c4"]."', '".$_POST["p_c5"]."', '".$_POST["p_c6"]."', '".$_POST["p_c7"]."', '".$_POST["p_c8"]."', '".$_POST["p_c9"]."', '".$_POST["p_c10"]."', '".$_POST["p_c11"]."', '".$_POST["p_c12"]."', '".$_POST["p_c13"]."', '".$_POST["p_c14"]."', '".$_POST["enable_character"]."');") or die (db_error());

			$dont_update = 1; //don't update product

			$s  = "";
			$s1 = "UPDATE ".PRODUCTS_TABLE." SET categoryID=categoryID, hurl='".$new_hurl."'";

		}

		//add pictures?

if ($_POST["enable_autores"] == 1)
{

		if (isset($_FILES["picture"]) && $_FILES["picture"]["name"] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES["picture"]["name"])) //upload
		{
			$_FILES["picture"]["name"] = str_replace(" ","_",$_FILES["picture"]["name"]);
			$r = move_uploaded_file($_FILES["picture"]["tmp_name"], "./products_pictures/".$_FILES["picture"]["name"]);
			if (!$r) //failed 2 upload
			{
				echo "<center><font color=red>".ERROR_FAILED_TO_UPLOAD_FILE."</font>\n<br><br>\n";
				echo "<a href=\"javascript:window.close();\">".CLOSE_BUTTON."</a></center></body>\n</html>";
				exit;
			}

			SetRightsToUploadedFile( "./products_pictures/".$_FILES["picture"]["name"] );

		//regular photo
		img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/".$pid.".jpg", RESIZE_NORMAL_X, RESIZE_NORMAL_Y);
		//thumbnail
		img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/S_".$pid.".jpg", RESIZE_SMALL_X, RESIZE_SMALL_Y);
		//enlarged photo
		img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/B_".$pid.".jpg", RESIZE_BIG_X, RESIZE_BIG_Y);
		//hit photo
		img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/H_".$pid.".jpg", 130, 130);
		//shoping cart photo
		img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/SC_".$pid.".jpg", 50, 50);

		$s .= ", picture='".$pid.".jpg'";
		$s1.= ", picture='".$pid.".jpg'";

		$s .= ", thumbnail='S_".$pid.".jpg'";
		$s1.= ", thumbnail='S_".$pid.".jpg'";

		$s .= ", big_picture='B_".$pid.".jpg'";
		$s1.= ", big_picture='B_".$pid.".jpg'";

		unlink("./products_pictures/".$_FILES["picture"]["name"]);
		}

}
else
{
		//regular photo
		if (isset($_FILES["picture"]) && $_FILES["picture"]["name"] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES["picture"]["name"])) //upload
		{
			$_FILES["picture"]["name"] = str_replace(" ","_",$_FILES["picture"]["name"]);
			$r = move_uploaded_file($_FILES["picture"]["tmp_name"], "./products_pictures/".$_FILES["picture"]["name"]);
			if (!$r) //failed 2 upload
			{
				echo "<center><font color=red>".ERROR_FAILED_TO_UPLOAD_FILE."</font>\n<br><br>\n";
				echo "<a href=\"javascript:window.close();\">".CLOSE_BUTTON."</a></center></body>\n</html>";
				exit;
			}

			SetRightsToUploadedFile( "./products_pictures/".$_FILES["picture"]["name"] );

			//hit photo
			img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/H_".$pid.".jpg", 130, 130);
			//shoping cart photo
			img_resize("./products_pictures/".$_FILES["picture"]["name"], "./products_pictures/SC_".$pid.".jpg", 50, 50);

			$s .= ", picture='".$_FILES["picture"]["name"]."'";
			$s1.= ", picture='".$_FILES["picture"]["name"]."'";
		}

		if (isset($_FILES["big_picture"]) && $_FILES["big_picture"]["name"] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES["big_picture"]["name"]))
		{
			$_FILES["big_picture"]["name"] = str_replace(" ","_",$_FILES["big_picture"]["name"]);
			$r = move_uploaded_file($_FILES["big_picture"]["tmp_name"], "./products_pictures/".$_FILES["big_picture"]["name"]);
			if (!$r) //failed 2 upload
			{
				echo "<center><font color=red>".ERROR_FAILED_TO_UPLOAD_FILE."</font>\n<br><br>\n";
				echo "<a href=\"javascript:window.close();\">".CLOSE_BUTTON."</a></center></body>\n</html>";
				exit;
			}

			SetRightsToUploadedFile( "./products_pictures/".$_FILES["big_picture"]["name"] );

			$s .= ", big_picture='".$_FILES["big_picture"]["name"]."'";
			$s1.= ", big_picture='".$_FILES["big_picture"]["name"]."'";
		}

		//thumbnail
		if (isset($_FILES["thumbnail"]) && $_FILES["thumbnail"]["name"] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES["thumbnail"]["name"]))
		{
			$_FILES["thumbnail"]["name"] = str_replace(" ","_",$_FILES["thumbnail"]["name"]);
			$r = move_uploaded_file($_FILES["thumbnail"]["tmp_name"], "./products_pictures/".$_FILES["thumbnail"]["name"]);
			if (!$r) //failed 2 upload
			{
				echo "<center><font color=red>".ERROR_FAILED_TO_UPLOAD_FILE."</font>\n<br><br>\n";
				echo "<a href=\"javascript:window.close();\">".CLOSE_BUTTON."</a></center></body>\n</html>";
				exit;
			}

			SetRightsToUploadedFile( "./products_pictures/".$_FILES["thumbnail"]["name"] );

			$s .= ", thumbnail='".$_FILES["thumbnail"]["name"]."'";
			$s1.= ", thumbnail='".$_FILES["thumbnail"]["name"]."'";
		}
}

		if (!isset($dont_update)) //update product info
		{
			$s .= " WHERE productID='".$_POST["save_product"]."'";
			$sc .= " WHERE productID='".$_POST["save_product"]."'";
			db_query($s) or die (db_error());
			db_query($sc) or die (db_error());
			$productID = $_POST["save_product"];
		}
		else //don't update (insert query is already completed)
		{
			$s1.= " WHERE productID=$pid";
			db_query($s1) or die (db_error());
			$productID = $pid;
		}

		update_products_Count_Value_For_Categories(0);
		
		$tags = "";
		if (!isset($_POST["tags"]) || trim($_POST["tags"])!="") 
		{
			$tagsarr = explode(',',$_POST["tags"]);

			$tagq=db_query("DELETE FROM ".TAGS_TABLE." WHERE pid='".$pid."'") or die (db_error());

			
			foreach($tagsarr as $tagline)
			{
				if (Trim($tagline)) $tagq = db_query("INSERT INTO ".TAGS_TABLE."(pid, tag, hurl) VALUES('".$pid."','".Trim($tagline)."','".to_url(Trim($tagline)).".html')") or die (db_error());				
			}
		}

		header("Location: admin.php?dpt=catalog&sub=products&categoryID=".$_POST["categoryID"]);
	   }

	   else //get product from db
	   {
		if ($_GET["productID"])
		{
			$tags = "";			
			$tagq=db_query("SELECT * FROM ".TAGS_TABLE." WHERE pid='".$_GET["productID"]."'") or die (db_error());
			while ( $tagres = db_fetch_row($tagq))
			{
				$tags .= $tagres[2].", ";			
			}

			//--------------------------------- �������������� �������������� -----------------------------
			$product_character=array();
			$qc = db_query("select Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable from ".CHARACTER_TABLE." where productID='".$_GET["productID"]."'") or die (db_error());
			$product_character = db_fetch_row($qc);
			//-----------------------------------------------------------------------------------


			$q = db_query("SELECT categoryID, name, description, customers_rating, Price, picture, in_stock, thumbnail, big_picture, brief_description, list_price, product_code, hurl, accompanyID, productID, brandID, meta_title, meta_keywords, meta_desc FROM ".PRODUCTS_TABLE." WHERE productID='".$_GET["productID"]."' ORDER BY productID ASC") or die (db_error());
			$row = db_fetch_row($q);
 			if (!$row) //product wasn't found
			{
				echo "<center><font color=red>".ERROR_CANT_FIND_REQUIRED_PAGE."</font>\n<br><br>\n";
				echo "<a href=\"javascript:window.close();\">".CLOSE_BUTTON."</a></center></body>\n</html>";
				exit;
			}

			if (isset($_GET["picture_remove"])) //delete items picture from server if requested
			{
				if ($_GET["picture_remove"] && file_exists("./products_pictures/".$row[$_GET["picture_remove"]]))
					unlink("./products_pictures/".$row[$_GET["picture_remove"]]);

				$picture = "none";
			}

			// ----------------------- �������� �������������� ���� --------------------------------------------
           		if (isset($_GET["thumb_delete"])) //delete items picture from server if requested
			{
			if ($_GET["thumb_delete"] && file_exists("./products_thumb/".$_GET["thumb_delete"]))
				unlink("./products_thumb/".$_GET["thumb_delete"]);
			if ($_GET["thumb_delete"] && file_exists("./products_thumb/P_".$_GET["thumb_delete"]))
				unlink("./products_thumb/P_".$_GET["thumb_delete"]);

			$q = db_query("DELETE FROM ".THUMB_TABLE." WHERE picture='".$_GET["thumb_delete"]."'") or die (db_error());

			}
			//-----------------------------------------------------------------------------------------

			if ($row[5] != "" && file_exists("./products_pictures/".$row[5])) {$row[5] = $row[5];} else {$row[5]="";}
			if ($row[7] != "" && file_exists("./products_pictures/".$row[7])) {$row[7] = $row[7];} else {$row[7]="";}
			if ($row[8] != "" && file_exists("./products_pictures/".$row[8])) {$row[8] = $row[8];} else {$row[8]="";}

			$title = $row[1];

			$thumb_pic = array();
			$ti=0;
			$qt = db_query("SELECT picture, description FROM ".THUMB_TABLE." WHERE productID='".$_GET["productID"]."'") or die (db_error());
			  while ($qe=mysql_fetch_array($qt))
			  { 
			    $thumb_pic[$ti][0] = $qe["picture"];
			    $thumb_pic[$ti][1] = $qe["description"];

			    $ti++;
			  }

			$smarty->assign("thumb_pic", $thumb_pic);

		}
		else //creating new item
		{
			$title = ADMIN_PRODUCT_NEW;
			$cat = isset($_GET["categoryID"]) ? $_GET["categoryID"] : 0;
			$row = array($cat,"","","",0,"",1,"","","",0,"","");

			$tags = "";			
		}
	   }

		$smarty->assign("product_edit", $row);
		$smarty->assign("product_character", $product_character);
		$smarty->assign("product_title", $title);
		$smarty->assign("product_tags", $tags);

		//category list
		$cats = fillTheCList(0,0);
		for ($i=0; $i<count($cats); $i++)
		{
			$a="";
			for ($j=0;$j<$cats[$i][5];$j++) $a .="&nbsp;&nbsp;";
			$a .= $cats[$i][1];
			$cats[$i][1] = $a;
		}


		$smarty->assign("cat_list", $cats);

		//accompany
		$accompany = array();
		$i=0;
		$result = db_query("SELECT categoryID, productID, name, brandID FROM ".PRODUCTS_TABLE) or die (db_error());

		while ($row = db_fetch_row($result))
			{
			$q = db_query("SELECT name FROM ".BRAND_TABLE." WHERE brandID=".$row[3]) or die (db_error());
			$rowbr=db_fetch_row($q);

			$accompany[$i][1] = $rowbr[0];
			$accompany[$i][2] = $row[1];
			$accompany[$i][3] = $row[2];
			$i++;
			}

		$smarty->assign("accompany_list", $accompany);

		//brand list

		$brand = array();
		$i=0;
		$result = db_query("SELECT * FROM ".BRAND_TABLE) or die (db_error());

		while ($row = db_fetch_row($result))
			{
			$brand[$i][0] = $row[0];
			$brand[$i][1] = $row[1];
			$i++;
			}


		$smarty->assign("brand_list", $brand);


		//set main template
		$smarty->assign("admin_sub_dpt", "catalog_products_edit.tpl.html");
	}

?>