<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2009 Supme. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	echo 'Acces denied to this module';
	die;
}

	if (!strcmp($sub, "brands"))
	{

		if (isset($_GET["save_successful"])) //show successful save confirmation message
		{
			$smarty->assign("configuration_saved", 1);
		}

		if (isset($_GET["del_brand"])) // delete page
		{
			//old picture
			$q = db_query("SELECT Pict FROM ".BRAND_TABLE." WHERE brandID='".$_GET["del_brand"]."'") or die (db_error());
			$row = db_fetch_row($q);

			//remove old picture...
			if (($row[0]) && file_exists("./products_pictures/$row[0]"))
			unlink("./products_pictures/$row[0]");

			$q = db_query("DELETE FROM ".BRAND_TABLE." WHERE brandID='".$_GET["del_brand"]."'") or die (db_error());

			header("Location: admin.php?dpt=catalog&sub=brands");
		}

		if (isset($_GET["brands"])) // edit page
		{
			$q = db_query("SELECT brandID, name, comment, Pict, description, brief, meta_title, meta_keywords, meta_desc FROM ".BRAND_TABLE." WHERE brandID='".$_GET["brands"]."'") or die (db_error());
			$p = db_fetch_row($q);

			$smarty->assign("new_brand", $_GET["brands"]);
		        $smarty->assign("brand_info", $p);
		}
		else
		{
			$smarty->assign("new_brand", "0");
		}

		if (isset($_POST["add_brand"]))
		{
			$brand_pic = str_replace(" ","_",$_FILES['brand_pic']['name']);

			if ($_POST["add_brand"])
			{

				//old picture
				$q = db_query("SELECT Pict FROM ".BRAND_TABLE." WHERE brandID='".$_POST["add_brand"]."'") or die (db_error());
				$row = db_fetch_row($q);
				//save changes
				db_query("UPDATE ".BRAND_TABLE." SET name='".$_POST["brand_name"]."', comment='".$_POST["brand_comment"]."', description='".$_POST["brand_text"]."', brief='".$_POST["brand_brief"]."', meta_title='".rusDoubleQuotes($_POST["meta_title"])."', meta_keywords='".rusDoubleQuotes($_POST["meta_keywords"])."', meta_desc='".rusDoubleQuotes($_POST["meta_desc"])."' WHERE brandID='".$_POST["add_brand"]."'");

				if (isset($_FILES['brand_pic']) && $_FILES['brand_pic']['name'] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp|png)$/i', $_FILES['brand_pic']['name'])) //upload
					{

					$brand_pic = str_replace(" ","_",$_FILES['brand_pic']['name']);

					if (!move_uploaded_file($_FILES['brand_pic']['tmp_name'], './products_pictures/'.$brand_pic)) //failed to upload
						{
						$smarty->assign("error", "loading error");
						}		
					else //update db
						{
						db_query("UPDATE ".BRAND_TABLE." SET Pict='".$brand_pic."' WHERE brandID='".$_POST["add_brand"]."'") or die (db_error());
						SetRightsToUploadedFile( "./products_pictures/".$brand_pic );
						}

					//remove old picture...
					if ($row[0] && strcmp($row[0], $brand_pic) && file_exists("./products_pictures/$row[0]"))
					unlink("./products_pictures/$row[0]");

					}

			}
			else //save new page
			{
			   if ($_POST["brand_name"])
			   {
				db_query("INSERT INTO ".BRAND_TABLE." (name, comment, Pict, description, brief, meta_title, meta_keywords, meta_desc) VALUES ('".$_POST["brand_name"]."','".$_POST["brand_comment"]."','".$brand_pic."','".$_POST["brand_text"]."','".$_POST["brand_brief"]."','".rusDoubleQuotes($_POST["meta_title"])."', '".rusDoubleQuotes($_POST["meta_keywords"])."', '".rusDoubleQuotes($_POST["meta_desc"])."');") or die (db_error());
				$pid = db_insert_id();
				if (isset($_FILES['brand_pic']) && $_FILES['brand_pic']['name'] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|bmp|png)$/i', $_FILES['brand_pic']['name'])) //upload
					{
					$brand_pic = str_replace(" ","_",$_FILES['brand_pic']['name']);
					$r = move_uploaded_file($_FILES['brand_pic']['tmp_name'], './products_pictures/'.$brand_pic);

					SetRightsToUploadedFile('./products_pictures/'.$brand_pic);
					}
			   }
			}



			header("Location: admin.php?dpt=catalog&sub=brands&save_successful=yes");
		}

		if (isset($_GET["picture_remove"]) && isset($_GET["brands"]) && ($_GET["brands"])) // remove picture
		{
			$q = db_query("SELECT Pict FROM ".BRAND_TABLE." WHERE brandID='".$_GET["brands"]."'") or die (db_error());
			$row = db_fetch_row($q);

			if (file_exists("./products_pictures/$row[0]"))	unlink("./products_pictures/$row[0]");
			
			db_query("UPDATE ".BRAND_TABLE." SET Pict='' WHERE brandID='".$_GET["brands"]."'") or die (db_error());

			header("Location: admin.php?dpt=catalog&sub=brands&brands=".$_GET["brands"]);
		}

		$brand_list=array();

		$q = db_query("SELECT brandID, name FROM ".BRAND_TABLE." ") or die (db_error());
		$i=0;
		while ($nm=mysql_fetch_array($q))
		{
			$brand_list[0][] = $nm["brandID"];

			if ($nm["brandID"] == $_GET["brands"])
				$brand_list[1][] = "<b>".$nm["name"]."</b>";
			else
				$brand_list[1][] = $nm["name"];
			$i++;
 		}


		$smarty->assign("brand_list", $brand_list);
		$smarty->assign("brand_list_count", $i);

		//set sub-department template
		$smarty->assign("admin_sub_dpt", "catalog_brands.tpl.html");
	}

?>
