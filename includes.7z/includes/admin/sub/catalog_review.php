<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//catalog: products extra parameters list

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!strcmp($sub, "review"))
	{
		if (isset($_GET["save_successful"])) //save extra product options
		{
			$smarty->assign("save_successful",ADMIN_UPDATE_SUCCESSFUL);
		}		
		if (isset($_POST["save_review"])) //save extra product options
		{

			//disable all products
			db_query("UPDATE ".PRODUCTS_TABLE." SET enabled = 0, in_stock = 0 WHERE categoryID='".$_POST["categoryID"]."'") or die (db_error());

			foreach ($_POST as $key => $val)
			{
			  if (strstr($key, "review_")) //update price
			  {
				db_query("UPDATE ".REVIEW_TABLE." SET review='$val' WHERE reviewID=".str_replace("review_","",$key)) or die (db_error());
			  }
			}
			header("Location: admin.php?dpt=catalog&sub=review&save_successful=yes&review=".$_POST["save_review"]);
		}

		if (isset($_GET["delete"]) && $_GET["delete"])
		{
			db_query("DELETE FROM ".REVIEW_TABLE." WHERE reviewID='".$_GET["delete"]."'");
			header("Location: admin.php?dpt=catalog&sub=review&review=".$_POST["save_review"]);
		}

		if (isset($_GET["review"]) && $_GET["review"])
		{
			//select product reviews by productID
			$q = db_query("SELECT reviewID, productID, username, email, review, date_time FROM ".REVIEW_TABLE." WHERE productID=".$_GET["review"]." ORDER BY date_time DESC") or die (db_error());
			$result = array();
			while ($row = db_fetch_row($q))
			{
				//get product name
				$q1 = db_query("select name from ".PRODUCTS_TABLE." where productID=$row[1]") or die (db_error());
				if ($row1 = db_fetch_row($q1))
				{
					$row[6] = $row1[0];
					$result[] = $row;
				}
			}
			$smarty->assign("savedID", $result[0][1]);
			$smarty->assign("reviews", $result);
		}
		else
		{
			//now select all product reviews
			$q = db_query("SELECT reviewID, productID, username, email, review, date_time FROM ".REVIEW_TABLE." ORDER BY date_time DESC") or die (db_error());
			$result = array();
			while ($row = db_fetch_row($q))
			{
				//get product name
				$q1 = db_query("select name from ".PRODUCTS_TABLE." where productID=$row[1]") or die (db_error());
				if ($row1 = db_fetch_row($q1))
				{
					$row[6] = $row1[0];
					$result[] = $row;
				}
			}
			$smarty->assign("reviews", $result);
		}

		//set sub-department template
		$smarty->assign("admin_sub_dpt", "catalog_review.tpl.html");
	}

?>