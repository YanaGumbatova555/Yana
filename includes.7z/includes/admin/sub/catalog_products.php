<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//products and categories tree view

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}
	//show new orders page if selected
	if (!strcmp($sub, "products"))
	{
		if (isset($_POST["products_update"])) { //save changes in current category

			//disable all products
			db_query("UPDATE ".PRODUCTS_TABLE." SET enabled = 0, in_stock = 0 WHERE categoryID='".$_POST["categoryID"]."'") or die (db_error());

			foreach ($_POST as $key => $val)
			{

			  if (strstr($key, "price_")) //update price
			  {
				$temp = $val;
				$temp = round($temp*100)/100;
				db_query("UPDATE ".PRODUCTS_TABLE." SET Price='$temp' WHERE productID=".str_replace("price_","",$key)) or die (db_error());
				db_query("UPDATE ".CHARACTER_TABLE." SET Prdct1='$temp' WHERE productID=".str_replace("price_","",$key)) or die (db_error());
			  }

			  if (strstr($key, "enable_")) //enable products
			  {
				db_query("UPDATE ".PRODUCTS_TABLE." SET enabled = 1 WHERE productID=".str_replace("enable_","",$key)) or die (db_error());
			  }

			  if (strstr($key, "instock_")) //in stock info
			  {
				$temp = $val;
				db_query("UPDATE ".PRODUCTS_TABLE." SET in_stock = ".$temp." WHERE productID=".str_replace("instock_","",$key)) or die (db_error());
			  }

			}

			update_products_Count_Value_For_Categories(0);

			header("Location: admin.php?dpt=catalog&sub=products&categoryID=".$_POST["categoryID"]);
		}
		else if (isset($_GET["terminate"])) //delete product
			{

			$q = db_query("SELECT picture, thumbnail, big_picture FROM ".PRODUCTS_TABLE." WHERE productID='".$_GET["terminate"]."'") or die (db_error());
			$row = db_fetch_row($q);

				//at first photos...
				if ($row[0] != "none" && $row[0] != "" && file_exists("./products_pictures/".$row[0]))
					unlink("./products_pictures/".$row[0]);
				if ($row[0] != "none" && $row[0] != "" && file_exists("./products_pictures/H_".$row[0]))
					unlink("./products_pictures/H_".$row[0]);
				if ($row[0] != "none" && $row[0] != "" && file_exists("./products_pictures/SC_".$row[0]))
					unlink("./products_pictures/SC_".$row[0]);
				if ($row[1] != "none" && $row[1] != "" && file_exists("./products_pictures/".$row[1]))
					unlink("./products_pictures/".$row[1]);
				if ($row[2] != "none" && $row[2] != "" && file_exists("./products_pictures/".$row[2]))
					unlink("./products_pictures/".$row[2]);

				db_query("DELETE FROM ".PRODUCTS_TABLE." WHERE productID='".$_GET["terminate"]."'");
				db_query("DELETE FROM ".CHARACTER_TABLE." WHERE productID='".$_GET["terminate"]."'");
				db_query("DELETE FROM ".THUMB_TABLE." WHERE productID='".$_GET["terminate"]."'");
				db_query("DELETE FROM ".TAGS_TABLE." WHERE pid='".$_GET["terminate"]."'");

				update_products_Count_Value_For_Categories(0);
				header("Location: admin.php?dpt=catalog&sub=products&categoryID=".$_GET["categoryID"]);
			}

		if (isset($_GET["dublicate_product"])) { //make a copy of product

			$q = db_query("SELECT categoryID, name, description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, items_sold, big_picture, enabled, brief_description, list_price, product_code, hurl, accompanyID, brandID, meta_title, meta_keywords, meta_desc FROM ".PRODUCTS_TABLE." WHERE productID='".$_GET["dublicate_product"]."'") or die (db_error());
			$row = db_fetch_row($q);

			db_query("INSERT INTO ".PRODUCTS_TABLE." (categoryID, name, description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, items_sold, big_picture, enabled, brief_description, list_price, product_code, hurl, accompanyID, brandID, meta_title, meta_keywords, meta_desc) VALUES ('".$row[0]."','".$row[1]."','".$row[2]."','".$row[3]."','".$row[4]."','','".$row[6]."','','".$row[8]."','".$row[9]."','','".$row[11]."','".$row[12]."','".$row[13]."','".$row[14]."','','".$row[16]."','".$row[17]."','".$row[18]."','".$row[19]."','".$row[20]."');") or die (db_error());
			$pid = db_insert_id();	

			$new_hurl=to_url($row[1])."_".$pid.".html";

			//regular photo
			img_resize("./products_pictures/".$row[10], "./products_pictures/".$pid.".jpg", RESIZE_NORMAL_X, RESIZE_NORMAL_Y);
			//thumbnail
			img_resize("./products_pictures/".$row[10], "./products_pictures/S_".$pid.".jpg", RESIZE_SMALL_X, RESIZE_SMALL_Y);
			//enlarged photo
			img_resize("./products_pictures/".$row[10], "./products_pictures/B_".$pid.".jpg", RESIZE_BIG_X, RESIZE_BIG_Y);
			//hit photo
			img_resize("./products_pictures/".$row[10], "./products_pictures/H_".$pid.".jpg", 130, 130);
			//shoping cart photo
			img_resize("./products_pictures/".$row[10], "./products_pictures/SC_".$pid.".jpg", 50, 50);

			db_query("UPDATE ".PRODUCTS_TABLE." SET picture='".$pid.".jpg', thumbnail='S_".$pid.".jpg', big_picture='B_".$pid.".jpg', hurl='".$new_hurl."' WHERE productID='".$pid."'") or die (db_error());

			$q = db_query("SELECT Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable FROM ".CHARACTER_TABLE." WHERE productID='".$_GET["dublicate_product"]."'") or die (db_error());
			$row = db_fetch_row($q);

			db_query("INSERT INTO ".CHARACTER_TABLE." (productID, Prdct1, Prdct2, Prdct3, Prdct4, Prdct5, Prdct6, Prdct7, Crtr1, Crtr2, Crtr3, Crtr4, Crtr5, Crtr6, Crtr7, Crtr8, enable) VALUES ('".$pid."','".$row[0]."','".$row[1]."','".$row[2]."','".$row[3]."','".$row[4]."','".$row[5]."','".$row[6]."','".$row[7]."','".$row[8]."','".$row[9]."','".$row[10]."','".$row[11]."','".$row[12]."','".$row[13]."','".$row[14]."','".$row[15]."');") or die (db_error());

			$q = db_query("SELECT picture, description FROM ".THUMB_TABLE." WHERE productID='".$_GET["dublicate_product"]."'") or die (db_error());

			while ($row = db_fetch_row($q))
			    db_query("INSERT INTO ".THUMB_TABLE." (productID, picture, description) VALUES ('".$pid."','".$row[0]."','".$row[1]."');") or die (db_error());	   


			//tags
			$tagq=db_query("SELECT * FROM ".TAGS_TABLE." WHERE pid='".$_GET["dublicate_product"]."'") or die (db_error());
			while ($rowt = db_fetch_row($tagq)) db_query("INSERT INTO ".TAGS_TABLE."(pid, tag, hurl) VALUES('".$pid."','".$rowt[2]."','".$rowt[3]."')") or die (db_error());


			header("Location: admin.php?dpt=catalog&sub=products&categoryID=".$_GET["categoryID"]);
			}

		//calculate how many products are there in the root category
		$q = db_query("SELECT count(*) FROM ".PRODUCTS_TABLE." WHERE categoryID=0") or die (db_error());
		$cnt = db_fetch_row($q);
		$smarty->assign("products_in_root_category",$cnt[0]);

		//create a category tree
		$c = fillTheCList(0,0);
		$smarty->assign("categories", $c);

		//show category name as a title
		$row = array();
		if (!isset($_GET["categoryID"]) && !isset($_POST["categoryID"]))
		{
			$categoryID = 0;
			$row[0] = ADMIN_CATEGORY_ROOT;
		}
		else //go to the root if category doesn't exist
		{
			$categoryID = isset($_GET["categoryID"]) ? $_GET["categoryID"] : $_POST["categoryID"];
			$q = db_query("SELECT name FROM ".CATEGORIES_TABLE." WHERE categoryID<>0 and categoryID='$categoryID'") or die (db_error());
			$row = db_fetch_row($q);
			if (!$row)
			{
				$categoryID = 0;
				$row[0] = ADMIN_CATEGORY_ROOT;
			}
		}

		$smarty->assign("categoryID", $categoryID);
		$smarty->assign("category_name", $row[0]);

		//get all products
		$q = db_query("SELECT productID, name, customers_rating, Price, in_stock, picture, big_picture, thumbnail, items_sold, enabled, product_code FROM ".PRODUCTS_TABLE." WHERE categoryID='$categoryID'  ORDER BY name;") or die (db_error());
		$result = array();
		$i=0;
		while ($row = db_fetch_row($q)) 
		  {
		    $q_r = db_query("SELECT * FROM ".REVIEW_TABLE." WHERE productID=".$row[0]) or die (db_error());
			$rev = 0;
			while ($row_r = db_fetch_row($q_r)) $rev++;
		    $row[] = $rev;
		    $result[$i++] = $row;
		  }
		//update result
		for ($i=0; $i<count($result); $i++)
		{
			if (!trim($result[$i][5]) || !file_exists("./products_pictures/".trim($result[$i][5])))
				$result[$i][5] = "";
			if (!trim($result[$i][6]) || !file_exists("./products_pictures/".trim($result[$i][6])))
				$result[$i][6] = "";
			if (!trim($result[$i][7]) || !file_exists("./products_pictures/".trim($result[$i][7])))
				$result[$i][7] = "";
		}

		//products list
		$smarty->assign("products", $result);

		//set main template
		$smarty->assign("admin_sub_dpt", "catalog_products.tpl.html");
	}

?>