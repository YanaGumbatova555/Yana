<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//appearence settings

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!strcmp($sub, "product"))
	{

		if (isset($_GET["save_successful"])) //show successful save confirmation message
		{
			$smarty->assign("configuration_saved", 1);
		}

		if (isset($_POST["save_conf"])) //save system settings
		{
			//modify checkbox vars
			if (!isset($_POST["add2cart"])) $_POST["add2cart"] = 0;
			if (!strcmp($_POST["add2cart"], "on")) $_POST["add2cart"] = 1;
			else $_POST["add2cart"] = 0;

			if (!isset($_POST["add2cartInStock"])) $_POST["add2cartInStock"] = 0;
			if (!strcmp($_POST["add2cartInStock"], "on")) $_POST["add2cartInStock"] = 1;
			else $_POST["add2cartInStock"] = 0;

			if (!isset($_POST["fast_order_on"])) $_POST["fast_order_on"] = 0;
			if (!strcmp($_POST["fast_order_on"], "on")) $_POST["fast_order_on"] = 1;
			else $_POST["fast_order_on"] = 0;

			if (!isset($_POST["float_quantity"])) $_POST["float_quantity"] = 0;
			if (!strcmp($_POST["float_quantity"], "on")) $_POST["float_quantity"] = 1;
			else $_POST["float_quantity"] = 0;


			if (!isset($_POST["productInStock"])) $_POST["productInStock"] = 0;
			if (!strcmp($_POST["productInStock"], "on")) $_POST["productInStock"] = 1;
			else $_POST["productInStock"] = 0;

			if ($_POST["float_quantity"] == 1) {$q = db_query("ALTER TABLE `SS_ordered_carts` CHANGE `Quantity` `Quantity` FLOAT( 11 ) NULL DEFAULT NULL ") or die (db_error());} else {$q = db_query("ALTER TABLE `SS_ordered_carts` CHANGE `Quantity` `Quantity` INT( 11 ) NULL DEFAULT NULL ") or die (db_error());}

			//appearence settings
			$f = fopen("./cfg/product_conf.inc.php","w");
			fputs($f,"<?php\n\tdefine('CONF_FAST_ORDER_ON', '".(int)$_POST["fast_order_on"]."');\n");
			fputs($f,"\tdefine('CONF_SHOW_ADD2CART', '".$_POST["add2cart"]."');\n");
			fputs($f,"\tdefine('CONF_SHOW_ADD2CART_INSTOCK', '".$_POST["add2cartInStock"]."');\n");
			fputs($f,"\tdefine('CONF_SHOW_PRODUCT_INSTOCK', '".$_POST["productInStock"]."');\n");
			fputs($f,"\tdefine('CONF_FAST_ORDER_COST', '".(int)$_POST["fast_order_cost"]."');\n");
			fputs($f,"\tdefine('CONF_FLOAT_QUANTITY', '".(int)$_POST["float_quantity"]."');\n");
			fputs($f,"\tdefine('CONF_MINIMAL_COUNT', '".(int)$_POST["minimal_count"]."');\n");
			fputs($f,"\tdefine('CONF_MINIMAL_SUMM', '".(int)$_POST["minimal_summ"]."');\n");
			fputs($f,"\tdefine('CONF_MINIMAL_PRODUCT', '".__escape_string($_POST["minimal_product"])."');\n");
			fputs($f,"\tdefine('CONF_MINIMAL_COST', '".(int)$_POST["minimal_cost"]."');\n");
			fputs($f,"\tdefine('CONF_DISCOUNT_VALUE', '".(int)$_POST["discount_val"]."');\n");
			fputs($f,"\tdefine('CONF_DISCOUNT_PR', '".(int)$_POST["discount_pr"]."');\n");
			fputs($f,"\tdefine('CONF_SORT_CATEGORY', '".__escape_string($_POST["category_sort"])."');\n");
			fputs($f,"\tdefine('CONF_SORT_CATEGORY_BY', '".__escape_string($_POST["category_sort_by"])."');\n");
			fputs($f,"\tdefine('CONF_SORT_PRODUCT', '".__escape_string($_POST["product_sort"])."');\n");
			fputs($f,"\tdefine('CONF_SORT_PRODUCT_BY', '".__escape_string($_POST["product_sort_by"])."');\n?>");

			fclose($f);

			header("Location: admin.php?dpt=conf&sub=product&save_successful=yes");
		}


		//set sub-department template
		$smarty->assign("admin_sub_dpt", "conf_product.tpl.html");
	}

?>