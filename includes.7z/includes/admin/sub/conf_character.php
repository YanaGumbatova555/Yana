<?php


	//company pages

if($_SESSION["id"] || !defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	echo 'Acces denied to this module';
	die;
}

	if (!strcmp($sub, "character"))
	{

		if (isset($_GET["save_successful"])) //show successful save confirmation message
		{
			$smarty->assign("configuration_saved", 1);
		}

		if (isset($_POST["save_character"])) //save system settings
		{

			//general settings
			$f = fopen("./cfg/character.inc.php","w");
			fputs($f,"<?php\n\tdefine('ADMIN_PRODUCT_CHARACTER1_DESC', '".__escape_string($_POST["character1_desc"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_0', '".__escape_string($_POST["character1_0"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_1', '".__escape_string($_POST["character1_1"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_2', '".__escape_string($_POST["character1_2"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_3', '".__escape_string($_POST["character1_3"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_4', '".__escape_string($_POST["character1_4"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_5', '".__escape_string($_POST["character1_5"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER1_6', '".__escape_string($_POST["character1_6"])."');\n");

			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER2_DESC', '".__escape_string($_POST["character2_desc"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER2_0', '".__escape_string($_POST["character2_0"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER2_1', '".__escape_string($_POST["character2_1"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER2_2', '".__escape_string($_POST["character2_2"])."');\n");

			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_DESC', '".__escape_string($_POST["character3_desc"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_0', '".__escape_string($_POST["character3_0"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_1', '".__escape_string($_POST["character3_1"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_2', '".__escape_string($_POST["character3_2"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_3', '".__escape_string($_POST["character3_3"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER3_4', '".__escape_string($_POST["character3_4"])."');\n");

			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER4_DESC', '".__escape_string($_POST["character4_desc"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER4_0', '".__escape_string($_POST["character4_0"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER4_1', '".__escape_string($_POST["character4_1"])."');\n");
			fputs($f,"\tdefine('ADMIN_PRODUCT_CHARACTER4_2', '".__escape_string($_POST["character4_2"])."');\n");

			fputs($f,"?>");
			fclose($f);

			header("Location: admin.php?dpt=conf&sub=character&save_successful=yes");
		}

		//set sub-department template
		$smarty->assign("admin_sub_dpt", "conf_character.tpl.html");
	}

?>