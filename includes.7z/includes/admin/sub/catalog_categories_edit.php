<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//categories edit

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!strcmp($sub, "categories_edit"))
	{

	    if (isset($_POST["categories_save"])) { //save changes in current category

		if (!isset($_POST["c_id"]) || $_POST["c_id"]=="") //add new category
			{
			$q = db_query("INSERT INTO ".CATEGORIES_TABLE." (name, parent, products_count, description, picture, products_count_admin, about, enabled, meta_title, meta_keywords, meta_desc) VALUES ('".rusDoubleQuotes($_POST["name"])."',".$_POST["parent"].",0,'".$_POST["desc"]."','',0,'".$_POST["about"]."',1 ,'".rusDoubleQuotes($_POST["meta_title"])."', '".rusDoubleQuotes($_POST["meta_keywords"])."', '".rusDoubleQuotes($_POST["meta_desc"])."')") or die (db_error());
			$pid = db_insert_id();
			}

		else //update existing category
			{
			    if ($_POST["hurl"]=="") {$new_hurl=to_url($_POST["name"]).".html";} else {$new_hurl=$_POST["hurl"];}

			    if ($_POST["c_id"] != $_POST["parent"]) //if not moving category to itself
			    {

				//if category is being moved to any of it's subcategories - it's
				//neccessary to 'lift up' all it's subcategories

				if (category_Moves_To_Its_SubDirectories($_POST["c_id"], $_POST["parent"]))
				{
					//lift up is required

					//get parent
					$q = db_query("SELECT parent FROM ".CATEGORIES_TABLE." WHERE categoryID<>0 and categoryID='".$_POST["c_id"]."'") or die (db_error());
					$r = db_fetch_row($q);

					//lift up
					db_query("UPDATE ".CATEGORIES_TABLE." SET parent='$r[0]' WHERE parent='".$_POST["c_id"]."'") or die (db_error());

					//move edited category
					db_query("UPDATE ".CATEGORIES_TABLE." SET name='".rusDoubleQuotes(str_replace("<","&lt;",$_POST["name"]))."', description='".$_POST["desc"]."', about='".$_POST["about"]."', parent='".$_POST["parent"]."', meta_title='".rusDoubleQuotes($_POST["meta_title"])."', meta_keywords='".rusDoubleQuotes($_POST["meta_keywords"])."', meta_desc='".rusDoubleQuotes($_POST["meta_desc"])."', hurl='".$new_hurl."' WHERE categoryID='".$_POST["c_id"]."'") or die (db_error());

				}
				else //just move category
					db_query("UPDATE ".CATEGORIES_TABLE." SET name='".rusDoubleQuotes(str_replace("<","&lt;",$_POST["name"]))."', description='".$_POST["desc"]."', about='".$_POST["about"]."', parent='".$_POST["parent"]."', meta_title='".rusDoubleQuotes($_POST["meta_title"])."', meta_keywords='".rusDoubleQuotes($_POST["meta_keywords"])."', meta_desc='".rusDoubleQuotes($_POST["meta_desc"])."', hurl='".$new_hurl."' WHERE categoryID='".$_POST["c_id"]."'") or die (db_error());
			    }

			$pid = $_POST["c_id"];

			//manual change ID
			if (($_POST["manual_input"] != $_POST["c_id"]) && ($_POST["manual_input"] >0))
				{
				db_query("UPDATE ".CATEGORIES_TABLE." SET parent='".$_POST["manual_input"]."' WHERE parent='".$_POST["c_id"]."'") or die (db_error());
				db_query("UPDATE ".CATEGORIES_TABLE." SET categoryID='".$_POST["manual_input"]."' WHERE categoryID='".$_POST["c_id"]."'") or die (db_error());
				db_query("UPDATE ".PRODUCTS_TABLE." SET categoryID='".$_POST["manual_input"]."' WHERE categoryID='".$_POST["c_id"]."'") or die (db_error());

				$pid = $_POST["manual_input"];
				}
			//enable category
			if (isset($_POST["category_enabled"]))
				{db_query("UPDATE ".CATEGORIES_TABLE." SET enabled='1' WHERE categoryID='".$_POST["c_id"]."' || parent='".$_POST["c_id"]."'") or die (db_error());}
			else	{db_query("UPDATE ".CATEGORIES_TABLE." SET enabled='0' WHERE categoryID='".$_POST["c_id"]."' || parent='".$_POST["c_id"]."'") or die (db_error());}



			update_products_Count_Value_For_Categories(0);
			}

		if (isset($_FILES["picture"]) && $_FILES["picture"]["name"] && preg_match('/\.(jpg|jpeg|gif|jpe|pcx|png|bmp)$/i', $_FILES["picture"]["name"])) //upload category thumbnail
			{

			//old picture
			$q = db_query("SELECT picture FROM ".CATEGORIES_TABLE." WHERE categoryID='".$pid."' and categoryID<>0") or die (db_error());
			$row = db_fetch_row($q);

			//upload new photo
			$picture_name = str_replace(" ","_", $_FILES["picture"]["name"]);
			if (!move_uploaded_file($_FILES["picture"]["tmp_name"], "./products_pictures/$picture_name")) //failed to upload
			{
			$smarty->assign("error", "loading error");
			}
			else //update db
			{
				db_query("UPDATE ".CATEGORIES_TABLE." SET picture='$picture_name' WHERE categoryID='".$pid."'") or die (db_error());
				SetRightsToUploadedFile( "./products_pictures/".$picture_name );
			}

			//remove old picture...
			if ($row[0] && strcmp($row[0], $picture_name) && file_exists("./products_pictures/$row[0]"))
				unlink("./products_pictures/$row[0]");
			}

		header("Location: admin.php?dpt=catalog&sub=categories");
		}

	    if (isset($_GET["picture_remove"])) //delete category thumbnail from server
		{
			$q = db_query("SELECT picture FROM ".CATEGORIES_TABLE." WHERE categoryID='".$_GET["c_id"]."' and categoryID<>0") or die (db_error());
			$r = db_fetch_row($q);
			if ($r[0] && file_exists("./products_pictures/$r[0]")) unlink("./products_pictures/$r[0]");
			db_query("UPDATE ".CATEGORIES_TABLE." SET picture='' WHERE categoryID='".$_GET["c_id"]."'") or die (db_error());
		}

	    if (isset($_GET["c_id"])) //edit existing category
		{
			$q = db_query("SELECT name, parent, description, picture, about, enabled, categoryID, meta_title, meta_keywords, meta_desc, hurl FROM ".CATEGORIES_TABLE." WHERE categoryID='".$_GET["c_id"]."' and categoryID<>0") or die (db_error());
			$row = db_fetch_row($q);

			$row[0] = str_replace("\"","&quot;",$row[0]);
			$row[2] = str_replace("\"","&quot;",$row[2]);
			if (!file_exists("./products_pictures/".$picture) || $row[3]=="") {$row[3] = "";}
			$row[4] = str_replace("\"","&quot;",$row[4]);

			$smarty->assign("cat_edit", $row);
		}

		//fill the category combobox
		
			$cats = fillTheCList(0,0);
			$smarty->assign("cats", $cats);
			$smarty->assign("cats_count", count($cats));

		//set main template
		$smarty->assign("admin_sub_dpt", "catalog_categories_edit.tpl.html");
	}

?>