<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//catalog: products extra parameters list

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!strcmp($sub, "present"))
	{

		if (isset($_GET["save_successful"])) //update was successful
		{
			$smarty->assign("save_successful",ADMIN_UPDATE_SUCCESSFUL);
		}

		if (isset($_POST["save_present"])) //save extra product options
		{
			//save existing
			db_query("delete from ".PRESENT_TABLE) or die (db_error());

			$present = array();
			foreach ($_POST as $key => $val)
			{
			  if(strstr($key, "present_productID_") != false)
			  {
				$a = str_replace("present_productID_","",$key);
				$present[$a]["productID"] = $val;
			  }

			  if(strstr($key, "present_value_") != false)
			  {
				$a = str_replace("present_value_","",$key);
				$present[$a]["value"] = $val;
			  }
			}

			foreach ($present as $key => $value)
			{
				db_query("insert into ".PRESENT_TABLE." ( productID, value) values ( '".$value["productID"]."', '".$value["value"]."')") or die (db_error());
			}
			header("Location: admin.php?dpt=catalog&sub=present&save_successful=yes");
		}

		if (isset($_GET["new_present"])) //add new present
		{
			db_query("INSERT INTO ".PRESENT_TABLE." (productID, value) VALUES ('".$_GET["new_present"]."', '0');") or die (db_error());
			header("Location: admin.php?dpt=catalog&sub=present");
		}

		if (isset($_GET["delete"])) //delete special offer
		{
			db_query("delete from ".PRESENT_TABLE." where presentID='".$_GET["delete"]."'") or die (db_error());
			header("Location: admin.php?dpt=catalog&sub=present");
		}

		//now select all available product options
		$q = db_query("select presentID, productID, value from ".PRESENT_TABLE." order by value") or die (db_error());
		$result = array();
		while ($row = db_fetch_row($q))
		{
			//get product name
			$q1 = db_query("select name, categoryID from ".PRODUCTS_TABLE." where productID=$row[1]") or die (db_error());
			if ($row1 = db_fetch_row($q1))
			{
				$row[3] = $row1[0];
				$row[4] = $row1[1];
				$result[] = $row;
			}
		}
		$smarty->assign("present", $result);

		//set sub-department template
		$smarty->assign("admin_sub_dpt", "catalog_present.tpl.html");
	}

?>