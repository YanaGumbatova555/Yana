<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//aux pages

if($_SESSION["id"] || !defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	echo 'Acces denied to this module';
	die;
}

	if (!strcmp($sub, "aux"))
	{

		if (isset($_GET["save_successful"])) //show successful save confirmation message
		{
			$smarty->assign("configuration_saved", 1);
		}

		if (isset($_POST["save_aux"])) //save system settings
		{
			//appearence settings
			$f = fopen("./cfg/index","w");
			$str = stripslashes( str_replace("\r\n","\n",$_POST["index_page"]) );
			fputs($f,$str);
			fclose($f);

			$f = fopen("./cfg/contact","w");
			$str = stripslashes( str_replace("\r\n","\n",$_POST["contact_page"]) );
			fputs($f,$str);
			fclose($f);

			$f = fopen("./cfg/aux1","w");
			$str = stripslashes( str_replace("\r\n","\n",$_POST["about_page"]) );
			fputs($f,$str);
			fclose($f);
			$f = fopen("./cfg/aux2","w");
			$str = stripslashes( str_replace("\r\n","\n",$_POST["shipping_page"]) );
			fputs($f,$str);
			fclose($f);


			//modify checkbox vars
			if (!isset($_POST["online_on"])) $_POST["online_on"] = 0;
			if (!strcmp($_POST["online_on"], "on")) $_POST["online_on"] = 1;
			else $_POST["online_on"] = 0;

			$f = fopen("./cfg/online.inc.php","w");
			fputs($f,"<?php\n\tdefine('CONF_ONLINE_ICQ', '".$_POST["online_icq"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_MA', '".$_POST["online_ma"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_SKY', '".$_POST["online_sky"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_ICQ_NAME', '".$_POST["online_icq_name"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_MA_NAME', '".$_POST["online_ma_name"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_SKY_NAME', '".$_POST["online_sky_name"]."');\n");
			fputs($f,"\tdefine('CONF_ONLINE_ON', '".(int)$_POST["online_on"]."');\n");
			fputs($f,"?>");
			fclose($f);

			header("Location: admin.php?dpt=inform&sub=aux&save_successful=yes");
		}

		$f = implode("",file("./cfg/aux1"));
		$smarty->assign("about_page", $f);
		$f = implode("",file("./cfg/aux2"));
		$smarty->assign("shipping_page", $f);
		$f = implode("",file("./cfg/index"));
		$smarty->assign("index_page", $f);
		$f = implode("",file("./cfg/contact"));
		$smarty->assign("contact_page", $f);

		//set sub-department template
		$smarty->assign("admin_sub_dpt", "inform_aux.tpl.html");
	}

?>