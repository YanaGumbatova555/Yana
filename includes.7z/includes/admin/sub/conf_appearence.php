<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//appearence settings

if(!defined('WORKING_THROUGH_ADMIN_SCRIPT'))
{
	die;
}

	if (!strcmp($sub, "appearence"))
	{

		if (isset($_GET["save_successful"])) //show successful save confirmation message
		{
			$smarty->assign("configuration_saved", 1);
		}

		if (isset($_POST["save_appearence"])) //save system settings
		{
			//modify checkbox vars
			if (!isset($_POST["bestchoice"])) $_POST["bestchoice"] = 0;
			if (!strcmp($_POST["bestchoice"], "on")) $_POST["bestchoice"] = 1;
			else $_POST["bestchoice"] = 0;
			if (!isset($_POST["showmenu"])) $_POST["showmenu"] = 0;
			if (!strcmp($_POST["showmenu"], "on")) $_POST["showmenu"] = 1;
			else $_POST["showmenu"] = 0;
			if (!isset($_POST["tagsview"])) $_POST["tagsview"] = 0;
			if (!strcmp($_POST["tagsview"], "on")) $_POST["tagsview"] = 1;
			else $_POST["tagsview"] = 0;


			//appearence settings
			$f = fopen("./cfg/appearence.inc.php","w");
			fputs($f,"<?php\n\tdefine('CONF_PRODUCTS_PER_PAGE', '".(int)$_POST["productscount"]."');\n");
			fputs($f,"\tdefine('CONF_COLUMNS_PER_PAGE', '".(int)$_POST["colscount"]."');\n");
			fputs($f,"\tdefine('CONF_MAX_HITS', '".(int)$_POST["hitscount"]."');\n");
			fputs($f,"\tdefine('CONF_SCROLL_HITS', '".(int)$_POST["scrollhits"]."');\n");
			fputs($f,"\tdefine('CONF_TAG_COUNT', '".(int)$_POST["tagscount"]."');\n");
			fputs($f,"\tdefine('CONF_TAG_VIEW_SW', '".(int)$_POST["tagsview"]."');\n");
			fputs($f,"\tdefine('CONF_SHOW_BEST_CHOICE', '".$_POST["bestchoice"]."');\n");
			fputs($f,"\tdefine('CONF_SHOW_MENU', '".$_POST["showmenu"]."');\n");
			fputs($f,"\tdefine('CONF_COLOR_SCHEME', '".__escape_string($_POST["color_scheme"])."');\n");
			fputs($f,"\tdefine('CONF_DARK_COLOR', '".__escape_string($_POST["darkcolor"])."');\n");
			fputs($f,"\tdefine('CONF_MIDDLE_COLOR', '".__escape_string($_POST["middlecolor"])."');\n");
			fputs($f,"\tdefine('CONF_LIGHT_COLOR', '".__escape_string($_POST["lightcolor"])."');\n");
			fputs($f,"\tdefine('CONF_VOTE_COLOR', '".__escape_string($_POST["votecolor"])."');\n");
			fputs($f,"\tdefine('RESIZE_SMALL_X', '".(int)$_POST["resize_small_x"]."');\n");
			fputs($f,"\tdefine('RESIZE_SMALL_Y', '".(int)$_POST["resize_small_y"]."');\n");
			fputs($f,"\tdefine('RESIZE_NORMAL_X', '".(int)$_POST["resize_normal_x"]."');\n");
			fputs($f,"\tdefine('RESIZE_NORMAL_Y', '".(int)$_POST["resize_normal_y"]."');\n");
			fputs($f,"\tdefine('RESIZE_BIG_X', '".(int)$_POST["resize_big_x"]."');\n");
			fputs($f,"\tdefine('RESIZE_BIG_Y', '".(int)$_POST["resize_big_y"]."');\n");
			fputs($f,"?>");
			fclose($f);

			header("Location: admin.php?dpt=conf&sub=appearence&save_successful=yes");
		}

		// Open a css directory, and proceed to read its schemes

		$dir = "./css/";

		if (is_dir($dir)) {
    			if ($dh = opendir($dir)) {
        			while (($file = readdir($dh)) !== false) {
				$res = explode('_', $file);
				if (!$res[1]=="") {$scheme[] = $res[1];}
	       		 	}
	        		closedir($dh);
	    		}
		}
		$smarty->assign("scheme_list", $scheme);


		//set sub-department template
		$smarty->assign("admin_sub_dpt", "conf_appearence.tpl.html");
	}

?>