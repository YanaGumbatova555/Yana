<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//ADMIN :: configuration

	//define admin department
	$admin_dpt = array(
		"id" => "conf", //department ID
		"sort_order" => 40, //sort order (less `sort_order`s appear first)
		"name" => ADMIN_SETTINGS, //department name
		"sub_departments" => array
		 (
			array("id"=>"general", "name"=>ADMIN_SETTINGS_GENERAL),
			array("id"=>"appearence", "name"=>ADMIN_SETTINGS_APPEARENCE),
			array("id"=>"company", "name"=>ADMIN_COMPANY_ABOUT),
			// array("id"=>"moder_pass", "name"=>"������ ����������"),
			array("id"=>"character", "name"=>ADMIN_CHARACTER),
			array("id"=>"product", "name"=>ADMIN_CATALOG_CONF)
		 )
	);
	add_department($admin_dpt);

	//show department if it is being selected
	if ($dpt == "conf")
	{
		//set default sub department if required
		if (!isset($sub)) $sub = "general";
		
		//assign admin main department template
		$smarty->assign("admin_main_content_template", $admin_dpt["id"].".tpl.html");
		//assign subdepts
		$smarty->assign("admin_sub_departments", $admin_dpt["sub_departments"]);
		//include selected sub-department
		if (file_exists("./includes/admin/sub/".$admin_dpt["id"]."_$sub.php")) //sub-department file exists
			include("./includes/admin/sub/".$admin_dpt["id"]."_$sub.php");
		else //no sub department found
			$smarty->assign("admin_main_content_template", "notfound.tpl.html");

		//curansy values
		if (CONF_CURRENCY_AUTO == 1)
			{

			$fh = @fopen('http://www.cbr.ru/scripts/XML_daily.asp','r');

			if($fh) {
				while(!feof($fh)) @$data.=fread($fh,4096);
				fclose($fh);
				preg_match('#<CharCode>USD</CharCode>.*?<Value>(.*?)</Value>#si',$data,$resultUSD);
				preg_match('#<CharCode>EUR</CharCode>.*?<Value>(.*?)</Value>#si',$data,$resultEUR);

				$resultUSD[1]= strval(str_replace(",",".",$resultUSD[1]));
				$resultEUR[1]= strval(str_replace(",",".",$resultEUR[1]));

				define("CURR_USD", round($resultUSD[1], 2));
				define("CURR_EUR", round($resultEUR[1], 2));
				}
			}
		else	{
			define('CURR_USD', CONF_CURRENCY_USD);
			define('CURR_EUR', CONF_CURRENCY_EUR);
			}


	}
	$admin_sub_menus['conf'] = $admin_dpt["sub_departments"];
	$smarty->assign("admin_sub_menus", $admin_sub_menus);
?>