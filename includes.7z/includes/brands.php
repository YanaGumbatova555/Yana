<?php
	//brand list

	$brandres = array();
	$i=0;
	$result = db_query("SELECT * FROM ".BRAND_TABLE) or die (db_error());

	while ($row = db_fetch_row($result))
		{
		if ($row[0] == $_GET['brands']) {$selected_brand = $row;}
		$brandres[$i][0] = $row[0];
		$brandres[$i][1] = $row[1];
		$i++;
		}

	$smarty->assign("brand_list", $brandres);

	//show all products of selected brand

	if (isset($_GET['brands']) && $_GET['brands'])
	{
		//get selected brand info
		if (!$selected_brand)
			{header("Location: index.php");}
		else {
			$smarty->assign("selected_brand", $selected_brand);
			$smarty->assign("meta_title", $selected_brand[6]);
			$smarty->assign("meta_keywords", $selected_brand[7]);
			$smarty->assign("meta_desc", $selected_brand[8]);
		     }

		//path to brand
			$path = Array();
			$row[0] = "index.php?brands=".$_GET["brands"];
			$row[1] = $selected_brand[1];
			$path[] = $row;

			$smarty->assign("product_category_path",$path);

		$smarty->assign("main_content_template", "brands.tpl.html");

		$q = db_query("SELECT count(*) FROM ".PRODUCTS_TABLE." WHERE brandID='".$_GET['brands']."'") or die (db_error());
		$g_count = db_fetch_row($q);
		$g_count = $g_count[0];

		$smarty->assign("catalog_navigator", NULL);
		$smarty->assign("products_to_show", NULL);
		$smarty->assign("products_to_show_count",NULL);

		if ($g_count) // there are products in the category
		{

			if ($offset > $g_count) $offset=0;

			$q = db_query("SELECT categoryID, ".PRODUCTS_TABLE.".name, brief_description, customers_rating, Price, picture, in_stock, thumbnail, customer_votes, big_picture, list_price, productID, product_code, hurl, items_sold, ".PRODUCTS_TABLE.".brandID, ".BRAND_TABLE.".name FROM ".PRODUCTS_TABLE." LEFT JOIN ".BRAND_TABLE." USING(brandID) WHERE ".PRODUCTS_TABLE.".brandID='".$_GET['brands']."' ORDER BY ".PRODUCTS_TABLE.".".$_SESSION["sort"]." ".$_SESSION["order"]) or die (db_error());

			//fetch all products
			$result = array();
			$i=0;
			while ($row = db_fetch_row($q))
			{
				if (isset($_GET["show_all"]) || ($i>=$offset && $i<$offset+CONF_PRODUCTS_PER_PAGE))
				{
					//update several product fields
					if (!file_exists("./products_pictures/".$row[5])) $row[5] = 0;
					if (!file_exists("./products_pictures/".$row[7])) $row[7] = 0;
					if (!file_exists("./products_pictures/".$row[9])) $row[9] = 0;
					$row[17] = show_price($row[4]);
					$row[18] = show_price($row[10]);
					$row[19] = show_price($row[10]-$row[4]); //you save (value)
					if ($row[10]) $row[20] = ceil(((($row[10]-$row[4])/$row[10])*100)); //you save (%)
					$row[21]= round($row[4]/CURR_USD);  //usd
					$row[22]= round($row[4]/CURR_EUR);  //eur

					if (($row[6] > 0) && (CONF_SHOW_ADD2CART > 0)) {$row[23]=1;}
					else 
					  if ((CONF_SHOW_ADD2CART_INSTOCK > 0) && (CONF_SHOW_ADD2CART > 0))
						{$row[23]=1;}
					  else {$row[23]=0;}

					if ($row[6] > 0) 
					    $result[] = $row;
					else 
					    if (CONF_SHOW_PRODUCT_INSTOCK > 0) {$result[] = $row;}
				}
				$i++;
			}

			//number of products to show on this page
			if (!isset($_GET["show_all"]))
			{
				$min = CONF_PRODUCTS_PER_PAGE;
				if ($min > $g_count-$offset) $min = $g_count-$offset;
			}
			else
			{
				$min = $g_count;
				$offset = "show_all";
			}

			$smarty->assign("products_to_show", $result);
			$smarty->assign("products_to_show_count", $min);

			$navigator = ""; //navigation links
			showNavigator($g_count, $offset, CONF_PRODUCTS_PER_PAGE, "index.php?brands=".$_GET['brands']."&",$navigator);
			$smarty->assign("catalog_navigator", $navigator);
		}
	}
?>