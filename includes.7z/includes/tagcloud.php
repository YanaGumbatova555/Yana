<?php
	$max=1;
	$q1 = db_query("SELECT tag, Count(id) as Cnt, hurl FROM ".TAGS_TABLE." GROUP BY tag ORDER BY Cnt DESC") or die (db_error());
	$row1 = db_fetch_row($q1);
	if($row1) $max=$row1[1];
	
	$q = db_query("SELECT tag, Count(id) as Cnt, hurl FROM ".TAGS_TABLE." GROUP BY tag") or die (db_error());
	$maxfont=22;
	$minfont=10;
	$tagcloud = "";
	$tagsearch = "";
	$tc=0;
	while (($row = db_fetch_row($q)) && ($tc < CONF_TAG_COUNT))
	{
	     $font =round(($max/$row[1])+$minfont);
	     if(($max/$row[1])==1) $font = $maxfont;
	     if($row[1]==1) $font = $minfont;
	     if($font<$minfont) $font=$minfont;
	     if($font>$maxfont) $font=$maxfont;

		if ($row[2]) {$href = "catalogt/".$row[2];} else {$href = "index.php?tagID=".$row[0];}

	     $tagcloud .=" <a href='".$href."' style='font-weigth:bold; font-size:".$font."px;'>$row[0]</a>";
	     $tagsearch .="'".$row[0]."',"."\n";
	     $tc++;
	}
	$tagsearch .= "''";
	$tagSwCloud = "<tags>".$tagcloud."</tags>";
	$smarty->assign("tagcloud",$tagcloud);
	$smarty->assign("tagSwCloud",$tagSwCloud);
	$smarty->assign("tagsearch",$tagsearch);
?>