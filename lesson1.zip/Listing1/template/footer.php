
			</div>
			<div id="footer">
			<hr/>
				<em>Все права защищены © 2012 г.</em>
				<br/>
				<em>Автор урока: Авдеев Марк.</em>
				<br/>
				<em>e-mail: <a href="mailto:mark-avdeev@mail.ru">mark-avdeev@mail.ru</a></em>
			</div>	
	</div>
	
</body>
</html>