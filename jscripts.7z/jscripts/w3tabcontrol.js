/*

w3tabcontrol - ������ ��� �������� �������
������: 1.0 �� 01.02.2008
������������: http://w3box.ru
��� ��������: freeware
w3box.ru � 2008

*/

function w3tabcontrol(obj_name, table_id)
{
	this.obj_name=obj_name;
	this.selected_tab=0;	
	this.tab_nav_nodes=new Array();
	this.tab_nodes=new Array();
	var t=document.getElementById(table_id);	
	var arr=t.getElementsByTagName('THEAD');
	this.tab_nav_nodes=arr[0].getElementsByTagName('A');
	for (var i=0; i<this.tab_nav_nodes.length; i++)
	{
		this.tab_nav_nodes[i].w3tabcontrol_object=this;
		this.tab_nav_nodes[i].w3tabcontrol_count=i;
		this.tab_nav_nodes[i].onclick=function () { this.w3tabcontrol_object.activate(this.w3tabcontrol_count); };
		if (this.tab_nav_nodes[i].hash==document.location.hash) this.selected_tab=i;
	}	
	arr=t.getElementsByTagName('TBODY');
	var tbody=arr[0];	
	arr=arr[0].getElementsByTagName('TD');
	var elements=arr[0].childNodes;	
	for (var i=0; i<elements.length; i++) if (elements[i].tagName==='DIV') this.tab_nodes[this.tab_nodes.length]=elements[i];	
	this.activate(this.selected_tab);
}

w3tabcontrol.prototype.activate=function(count)
{
	this.tab_nodes[this.selected_tab].style.display='none';
	this.tab_nav_nodes[this.selected_tab].className='';
	this.selected_tab=count;
	this.tab_nodes[this.selected_tab].style.display='block';
	this.tab_nav_nodes[this.selected_tab].className='selected';
}