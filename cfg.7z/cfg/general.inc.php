<?php
	define('CONF_SHOP_NAME', 'Shop-Script Free');
	define('CONF_SHOP_DESCRIPTION', 'Shop-Script Free, powered by Shop-Script');
	define('CONF_SHOP_KEYWORDS', 'Shop-Script Free, powered by Shop-Script');
	define('CONF_SHOP_URL', 'wrleg');
	define('CONF_GENERAL_EMAIL', 'mail@mail.ru');
	define('CONF_ORDERS_EMAIL', 'mail@mail.ru');
	define('CONF_CURRENCY_USD', '30.76');
	define('CONF_CURRENCY_EUR', '45.26');
	define('CONF_CURRENCY_AUTO', '1');
	define('CONF_CURRENCY_ID_LEFT', '');
	define('CONF_CURRENCY_ID_RIGHT', ' ���.');
	define('CONF_CURRENCY_ISO3', 'RUR');
?>