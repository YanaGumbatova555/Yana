<?php
	define('CONF_FAST_ORDER_ON', '0');
	define('CONF_SHOW_ADD2CART', '1');
	define('CONF_SHOW_ADD2CART_INSTOCK', '1');
	define('CONF_SHOW_PRODUCT_INSTOCK', '1');
	define('CONF_FAST_ORDER_COST', '1000');
	define('CONF_FLOAT_QUANTITY', '1');
	define('CONF_MINIMAL_COUNT', '0');
	define('CONF_MINIMAL_SUMM', '10000');
	define('CONF_MINIMAL_PRODUCT', '�������� ������');
	define('CONF_MINIMAL_COST', '1000');
	define('CONF_DISCOUNT_VALUE', '20000');
	define('CONF_DISCOUNT_PR', '5');
	define('CONF_SORT_CATEGORY', 'categoryID');
	define('CONF_SORT_CATEGORY_BY', 'ASC');
	define('CONF_SORT_PRODUCT', 'productID');
	define('CONF_SORT_PRODUCT_BY', 'ASC');
?>