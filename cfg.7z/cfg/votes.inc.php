<?php
	define('CONF_VOTES_ON', '1');
	define('CONF_VOTES_IP', '0');
	define('CONF_VOTES_TOMAIL', '0');
?>