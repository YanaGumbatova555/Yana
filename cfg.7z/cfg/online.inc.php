<?php
	define('CONF_ONLINE_ICQ', '345345345');
	define('CONF_ONLINE_MA', 'sibbear@inbox.ru');
	define('CONF_ONLINE_SKY', 'sibbear');
	define('CONF_ONLINE_ICQ_NAME', 'SibBear');
	define('CONF_ONLINE_MA_NAME', 'SibBear');
	define('CONF_ONLINE_SKY_NAME', 'SibBear');
	define('CONF_ONLINE_ON', '1');
?>