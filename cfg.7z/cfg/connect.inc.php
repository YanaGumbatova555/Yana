<?php
	//database connection settings

	define('DB_HOST', 'localhost'); // database host
	define('DB_USER', 'root'); // username
	define('DB_PASS', ''); // password
	define('DB_NAME', 'le2'); // database name
	define('ADMIN_LOGIN', 'YWRtaW4='); //administrator's login
	define('ADMIN_PASS', '202cb962ac59075b964b07152d234b70'); //administrator's login

	//database tables
	if(file_exists("./cfg/tables.inc.php")) include("./cfg/tables.inc.php");

?>