<?php
	//Shop-Script FREE database tables
	define('PRODUCTS_TABLE', 'SS_products');
	define('ORDERS_TABLE', 'SS_orders');
	define('ORDERED_CARTS_TABLE', 'SS_ordered_carts');
	define('CATEGORIES_TABLE', 'SS_categories');
	define('SPECIAL_OFFERS_TABLE', 'SS_special_offers');
	define('TAGS_TABLE', 'SS_tags');
	define('PAGES_TABLE','SS_pages');
	define('NEWS_TABLE','SS_news');
	define('CHARACTER_TABLE','SS_character');
	define('THUMB_TABLE','SS_thumb');
	define('PRESENT_TABLE','SS_present');
	define('REVIEW_TABLE','SS_review');
	define('BRAND_TABLE','SS_brand');
	define('VOTES_TABLE','SS_votes');
	define('VOTES_CONTENT_TABLE','SS_votes_content');
?>