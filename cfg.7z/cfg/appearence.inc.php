<?php
	define('CONF_PRODUCTS_PER_PAGE', '10');
	define('CONF_COLUMNS_PER_PAGE', '1');
	define('CONF_MAX_HITS', '10');
	define('CONF_SCROLL_HITS', '3');
	define('CONF_TAG_COUNT', '9999');
	define('CONF_TAG_VIEW_SW', '1');
	define('CONF_SHOW_BEST_CHOICE', '1');
	define('CONF_SHOW_MENU', '0');
	define('CONF_COLOR_SCHEME', 'default');
	define('CONF_DARK_COLOR', 'FFFFFF');
	define('CONF_MIDDLE_COLOR', 'FFFFFF');
	define('CONF_LIGHT_COLOR', 'FFFFFF');
	define('CONF_VOTE_COLOR', 'FD5300');
	define('RESIZE_SMALL_X', '150');
	define('RESIZE_SMALL_Y', '150');
	define('RESIZE_NORMAL_X', '220');
	define('RESIZE_NORMAL_Y', '220');
	define('RESIZE_BIG_X', '600');
	define('RESIZE_BIG_Y', '600');
?>