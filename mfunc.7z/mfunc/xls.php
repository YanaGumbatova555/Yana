<?php
$ctype = "application/vnd.ms-excel"; 
header("Pragma: public");
header("Expires: 0");
header("Accept-Ranges: bytes");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: $ctype; charset=windows-1251"); 
header('Content-Disposition: attachment; filename=price.xls');
header("Content-Transfer-Encoding: binary");

	//ini_set("display_errors", "1");
	//include core files

	include("../cfg/connect.inc.php");
	include("../cfg/tables.inc.php");
	include("../includes/database/mysql.php");
	include("../cfg/general.inc.php");
	include("../cfg/appearence.inc.php");
	include("../cfg/functions.php");
	include("../cfg/category_functions.php");
	include("../cfg/language_list.php");

	function inttobolstr($n)
	{
	    $res = "-";
	    if($n>0) $res="+";
	    return $res;
	}

	function removeEmptyLines($string)
	{
	     return preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $string);
	}
	
	echo '<link rel="stylesheet" type="text/css" media="all" href="http://'.CONF_SHOP_URL.'/css/price.css" />';

	db_connect(DB_HOST,DB_USER,DB_PASS) or die (db_error());
	db_select_db(DB_NAME) or die (db_error());
	$pt=PRODUCTS_TABLE; $ct=CATEGORIES_TABLE;
	$q = db_query("SELECT  $pt.productID, $ct.name as catname, $pt.name as prodname, $pt.Price, $pt.in_stock FROM $pt INNER JOIN $ct ON $pt.categoryID = $ct.categoryID WHERE $ct.enabled=1 ORDER BY catname");
	echo "<table>\n\t<thead>\n\t\t<tr>\n\t\t\t<td>Code</td>\n\t\t\t<td>Group</td>\n\t\t\t<td>Product</td>\n\t\t\t<td>Price</td>\n\t\t\t<td>Q</td>\n\t\t</tr>\n\t</thead>\n<tbody>";
	while ($row = db_fetch_row($q))
	{
		echo "\t<tr>\n";
		echo "\t\t<td>".$row[0]."</td>\n";
		echo "\t\t<td>".$row[1]."</td>\n";
		echo "\t\t<td>".$row[2]."</td>\n";
		$price = $row[3];
		$price +=.0000;
		echo "\t\t<td class=\"digit\">".number_format($price, 2, ',', '')."</td>\n";
		echo "\t\t<td>".inttobolstr($row[4])."</td>\n";
		echo "\t</tr>\n";
	}
	echo "</tbody>\n</table>\n";
?>