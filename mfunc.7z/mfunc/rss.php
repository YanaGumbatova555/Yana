<?php
	include("../cfg/connect.inc.php");
	include("../cfg/tables.inc.php");
	include("../includes/database/mysql.php");
	include("../cfg/general.inc.php");
	include("../cfg/appearence.inc.php");
	include("../cfg/functions.php");
	include("../cfg/category_functions.php");
	include("../cfg/language_list.php");
	function removeEmptyLines($string) { return preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $string); }
	      header("Content-type: text/xml");
	      echo "<?xml version=\"1.0\" encoding=\"windows-1251\"?>\n";	
	      echo "<rss version=\"2.0\">\n";
	      echo "<channel>\n";
	      echo "<title>".CONF_SHOP_NAME."</title>\n";
	      echo "<link>http://".CONF_SHOP_URL."/</link>\n";
	      echo "<description>".CONF_SHOP_NAME."</description>\n";
	      echo "<language>ru-RU</language>\n";
	      echo "<docs>http://blogs.law.harvard.edu/tech/rss</docs>\n";
	      echo "<generator>Shop-Script FREE</generator>\n";
	      echo "<managingEditor>".CONF_GENERAL_EMAIL."</managingEditor>\n";
	      echo "<webMaster>".CONF_GENERAL_EMAIL."</webMaster>\n";
	      echo "<lastBuildDate>".date("r")."</lastBuildDate>\n";
		db_connect(DB_HOST,DB_USER,DB_PASS) or die (db_error());
		db_select_db(DB_NAME) or die (db_error());
		$q = db_query("SELECT name, SUBSTRING(description, 1, 600) AS descr, thumbnail, productID FROM  ".PRODUCTS_TABLE." ORDER BY productID DESC LIMIT 10");
		while ($row = db_fetch_row($q))
		{
			echo "\t<item>\n";
			echo "\t\t<title>".$row[0]."</title>\n";
			echo "\t\t<link>http://".CONF_SHOP_URL."/index.php?productID=".$row[3]."</link>\n";
			echo "\t\t<guid>http://".CONF_SHOP_URL."/index.php?productID=".$row[3]."</guid>\n";			
			if ($row[2] & file_exists("products_pictures/".$row[2])) echo "\t\t<enclosure url=\"http://".CONF_SHOP_URL."/products_pictures/".$row[2]."\" length=\"".filesize("products_pictures/".$row[2])."\" type=\"image/jpeg\" />\n";
			$desc=strip_tags($row[1]);
			$desc=str_replace("&","&amp;",$desc);
			echo "\t\t<description>".$desc."</description>\n";
			echo "\t</item>\n";
		}
   	       echo "</channel>";
	       echo "</rss>";
?>