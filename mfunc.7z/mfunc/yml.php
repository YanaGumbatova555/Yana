<?php
	include("../cfg/connect.inc.php");
	include("../cfg/tables.inc.php");
	include("../includes/database/mysql.php");
	include("../cfg/general.inc.php");
	include("../cfg/appearence.inc.php");
	include("../cfg/functions.php");
	include("../cfg/category_functions.php");
	include("../cfg/language_list.php");
	function inttobolstr($n)
	{
	    $res = "false";
	    if($n>0) $res="true";
	    return $res;
	}
	function removeEmptyLines($string)
	{
	     return preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $string);
	}
	db_connect(DB_HOST,DB_USER,DB_PASS) or die (db_error());
	db_select_db(DB_NAME) or die (db_error());
	header("Content-type: text/xml");
	echo "<?xml version=\"1.0\" encoding=\"windows-1251\"?>\n";
	echo "<!DOCTYPE yml_catalog SYSTEM \"shops.dtd\">\n";
	echo "<yml_catalog date=\"".date("Y-m-d H:i")."\">\n";
	echo "<shop>\n";
	echo "\t<name>".CONF_SHOP_NAME."</name>\n";
	echo "\t<company>".CONF_SHOP_NAME."</company>\n";
	echo "\t<url>".CONF_SHOP_URL."</url>\n";
	echo "\t<currencies>\n\t\t<currency id=\"RUR\" rate=\"1\"/>\n\t</currencies>\n";
	echo "\t<categories>\n";
	$q = db_query("SELECT categoryID, name, parent, products_count FROM ".CATEGORIES_TABLE." where categoryID<>0 ORDER BY name") or die (db_error());	
	while ($row = db_fetch_row($q))
	{
		echo  "\t\t<category id=\"".$row[0]."\" parentId=\"".$row[2]."\">".$row[1]."</category>\n";
	}	
	echo "\t</categories>\n";
	echo "\t<offers>\n";
	$pt=PRODUCTS_TABLE;
	$ct=CATEGORIES_TABLE;
	$q = db_query("SELECT  $pt.productID, $ct.name as catname, $pt.name as prodname, $pt.description, $pt.Price, $pt.picture, $pt.in_stock, $pt.categoryID FROM $pt INNER JOIN $ct ON $pt.categoryID = $ct.categoryID");
	while ($row = db_fetch_row($q))
	{
		echo "\t\t<offer id=\"".$row[0]."\" available=\"".inttobolstr($row[6])."\">\n";
		echo "\t\t\t<url>http://".CONF_SHOP_URL."/index.php?productID=".$row[0]."</url>\n";
		echo "\t\t\t<price>".$row[4]."</price>\n";
		echo "\t\t\t<currencyId>RUR</currencyId>\n";
		echo "\t\t\t<categoryId>".$row[7]."</categoryId>\n";
		$pp = "";
		if ($row[5]) $pp = "http://".CONF_SHOP_URL."/products_pictures/".$row[5];
		echo "\t\t\t<picture>$pp</picture>\n";
		echo "\t\t\t<delivery>false</delivery>\n";
		echo "\t\t\t<name>".$row[2]."</name>\n";
		$zz=strip_tags($row[3]);
		$zz=str_replace("&","&amp;",$zz);
		echo "\t\t\t<description>".removeEmptyLines($zz)."</description>\n";
		echo "\t\t</offer>\n";
	}
	
	echo "\t</offers>\n";
echo "</shop>\n";
echo "</yml_catalog>";
?>