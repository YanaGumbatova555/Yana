<?php
	include("../cfg/connect.inc.php");
	include("../cfg/appearence.inc.php");
	include("../includes/database/mysql.php");
	include("../cfg/company.inc.php");
	include("money.class.php");
	include("../cfg/tables.inc.php");
	include("../cfg/product_conf.inc.php");
	include("../languages/russian.php");
	include("../cfg/functions.php");
	include("../cfg/general.inc.php");

	session_start();

	db_connect(DB_HOST,DB_USER,DB_PASS) or die (db_error());
	db_select_db(DB_NAME) or die (db_error());

		$q = db_query("SELECT orderID, cust_firstname, cust_lastname, cust_email, cust_city, cust_address, cust_phone, comment FROM ".ORDERS_TABLE." WHERE orderID=".$_SESSION["order_id"]) or die (db_error());
		$result = db_fetch_row($q);
		
		$q = db_query("SELECT name, Price, Quantity FROM ".ORDERED_CARTS_TABLE." WHERE orderID=".$result[0]."") or die(db_error());
		while ($row = db_fetch_row($q))
		{		
			if ($row[0] == ADMIN_DISCOUNT_STRING)
			{
			    $total -= $row[1]*$row[2];

			    $row[4] = "&nbsp;<br /><b>".show_price($row[1]*$row[2])."</b>";
			    $row[0] = "&nbsp;<br /><b>".$row[0]."</b>";
			    $row[1] = "";
			    $row[2] = "";
			    $res[] = Array();
			    $res[] = $row;
			}
			else
			{
			    $total += $row[1]*$row[2];

			    $row[4] = show_price($row[1]*$row[2]);
			    $row[1] = show_price($row[1]);
			    $res[] = $row;
			}	
		}

		$result[8] = show_price($total); //order value

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr" >

<head>
<title>����� �<?php echo $result[0]; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo DEFAULT_CHARSET; ?>">

<style type="text/css">

html {
	overflow: -moz-scrollbars-vertical;
	margin: 0;
	padding: 0;
}
* {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	
}

</style>
</head>
<body onload="print(); return false;">

	<img src="./css/css_<?php echo CONF_COLOR_SCHEME; ?>/image/logo0000.png"" alt=""/><br />
	<hr style="width: 800px; float: left;" />
	<br />
	<br />
	<table cellspacing="0" cellpadding="0" width="800px">
	  <tr>
	    <td style="width: 150px"><b><?php echo ORDER_ORDERER; ?>:</b></td>
	    <td><?php echo $result[1]." ".$result[2]; ?></td>
	  </tr>
	  <tr>
	    <td style="width: 150px"><b><?php echo ORDER_PHONE; ?>:</b></td>
	    <td><?php echo $result[6]; ?></td>
	  </tr>
	  <tr>
	    <td style="width: 150px"><b><?php echo ORDER_EMAIL; ?>:</b></td>
	    <td><?php echo $result[3]; ?></td>
	  </tr>
	  <tr style="vertical-align: top;">
	    <td style="width: 150px"><b><?php echo ORDER_ADRESS; ?>:</b></td>
	    <td><?php echo $result[4].",<br />".$result[5]; ?></td>
	  </tr>
	</table>
	<br />
	<br />
	<span style="font-weight: bold;" >����� �����: <?php echo $result[0]; ?></span>
	<br />
	<br />
	<table cellspacing="0" cellpadding="0" width="800px">
	  <tr style="font-weight: bold;">
	    <td></td>
	    <td style="text-align: center; width: 1px;"><?php echo TABLE_PRODUCT_QUANTITY; ?></td>
	    <td style="text-align: center; width: 100px;"><?php echo ADMIN_PRODUCT_PRICE; ?></td>
	    <td style="text-align: center; width: 100px;"><?php echo TABLE_PRODUCT_SUMM; ?></td>
	  </tr>
	<?php
	for ($i=0; $i<count($res); $i++)
	echo '
	  <tr>
	    <td >'.$res[$i][0].'</td>
	    <td style="text-align: center; width: 1px;">'.$res[$i][2].'</td>
	    <td style="text-align: right; width: 100px;">'.$res[$i][1].'</td>
	    <td style="text-align: right; width: 100px;">'.$res[$i][4].'</td>
	  </tr>';
	?>
	  <tr style="font-weight: bold;">
	    <td>&nbsp;<br /><?php echo TABLE_TOTAL; ?>:</td>
	    <td></td>
	    <td></td>
	    <td style="text-align: right; width: 100px;">&nbsp;<br /><?php echo $result[8]; ?></td>
	  </tr>
	</table>
	<br />
	<b><?php echo CUSTOMER_COMMENT; ?></b>
	<br />
	<?php echo $result[7]; ?>
	<br />
	<br />
	<hr style="width: 800px; float: left;" />
	<br />
	<br />
    <b><i><?php echo CONF_SHOP_NAME; ?><br />www.<?php echo CONF_SHOP_URL; ?></a></i></b>	
</body>
</html>